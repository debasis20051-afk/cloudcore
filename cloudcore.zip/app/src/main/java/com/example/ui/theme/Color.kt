package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary brand colors - Cloud gaming cyber aesthetic
val CloudCyan = Color(0xFF00E5FF)
val CloudCyanDark = Color(0xFF00B4D8)
val CloudViolet = Color(0xFF8B5CF6)
val CloudPurple = Color(0xFF6366F1)
val CloudEmerald = Color(0xFF10B981)
val CloudAmber = Color(0xFFF59E0B)
val CloudRose = Color(0xFFF43F5E)

// Dark surface palette
val DarkBg = Color(0xFF090D16)
val DarkSurface = Color(0xFF0F172A)
val DarkSurfaceElevated = Color(0xFF1E293B)
val DarkSurfaceHighlight = Color(0xFF334155)
val DarkCardBorder = Color(0xFF2E3D52)

// Google Play branding accents
val PlayGreen = Color(0xFF01875F)
val PlayBlue = Color(0xFF02569B)

// Chrome branding accents
val ChromeRed = Color(0xFFEA4335)
val ChromeYellow = Color(0xFFFBBC05)
val ChromeGreen = Color(0xFF34A853)
val ChromeBlue = Color(0xFF4285F4)

// Text and icons
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
