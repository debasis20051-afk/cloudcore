package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Authentic, pixel-perfect real application icons for CloudCore virtual phone desktop,
 * app drawer, Play Store catalog, and running window titlebars.
 */
@Composable
fun RealAppIcon(
    appId: String,
    title: String = "",
    size: Dp = 54.dp,
    modifier: Modifier = Modifier
) {
    val idLower = appId.lowercase()
    val titleLower = title.lowercase()

    Box(
        modifier = modifier
            .size(size)
            .shadow(4.dp, RoundedCornerShape(14.dp), clip = false)
            .clip(RoundedCornerShape(14.dp)),
        contentAlignment = Alignment.Center
    ) {
        when {
            // --- ROBLOX ---
            idLower.contains("roblox") || titleLower.contains("roblox") -> {
                RobloxAppIcon()
            }

            // --- MINECRAFT ---
            idLower.contains("minecraft") || titleLower.contains("minecraft") -> {
                MinecraftAppIcon()
            }

            // --- FREE FIRE ---
            idLower.contains("freefire") || titleLower.contains("free fire") -> {
                FreeFireAppIcon()
            }

            // --- PUBG MOBILE ---
            idLower.contains("pubg") || titleLower.contains("pubg") -> {
                PubgAppIcon()
            }

            // --- CALL OF DUTY ---
            idLower.contains("callofduty") || idLower.contains("cod") || titleLower.contains("call of duty") -> {
                CodMobileAppIcon()
            }

            // --- GENSHIN IMPACT ---
            idLower.contains("genshin") || titleLower.contains("genshin") -> {
                GenshinAppIcon()
            }

            // --- SUBWAY SURFERS ---
            idLower.contains("subway") || titleLower.contains("subway") -> {
                SubwaySurfersAppIcon()
            }

            // --- TIKTOK ---
            idLower.contains("tiktok") || idLower.contains("musically") || titleLower.contains("tiktok") -> {
                TikTokAppIcon()
            }

            // --- INSTAGRAM ---
            idLower.contains("instagram") || titleLower.contains("instagram") -> {
                InstagramAppIcon()
            }

            // --- WHATSAPP ---
            idLower.contains("whatsapp") || titleLower.contains("whatsapp") -> {
                WhatsAppAppIcon()
            }

            // --- FACEBOOK ---
            idLower.contains("facebook") || idLower.contains("katana") || titleLower.contains("facebook") -> {
                FacebookAppIcon()
            }

            // --- NETFLIX ---
            idLower.contains("netflix") || titleLower.contains("netflix") -> {
                NetflixAppIcon()
            }

            // --- X / TWITTER ---
            idLower.contains("twitter") || idLower == "com.x.android" || titleLower == "x" || titleLower.contains("twitter") -> {
                XTwitterAppIcon()
            }

            // --- REDFINGER CLOUD APP STORE (NO SIGN-IN) ---
            idLower.contains("vending") || idLower.contains("play_store") || idLower.contains("appstore") || titleLower.contains("app store") || titleLower.contains("play store") -> {
                CloudAppStoreIcon()
            }

            // --- GOOGLE CHROME ---
            idLower.contains("chrome") || titleLower.contains("chrome") -> {
                GoogleChromeIcon()
            }

            // --- GOOGLE DRIVE ---
            idLower.contains("docs") || idLower.contains("drive") || titleLower.contains("drive") -> {
                GoogleDriveIcon()
            }

            // --- YOUTUBE ---
            idLower.contains("youtube") || titleLower.contains("youtube") -> {
                YouTubeIcon()
            }

            // --- TELEGRAM ---
            idLower.contains("telegram") || titleLower.contains("telegram") -> {
                TelegramIcon()
            }

            // --- VLC MEDIA PLAYER ---
            idLower.contains("vlc") || titleLower.contains("vlc") -> {
                VlcPlayerIcon()
            }

            // --- TERMUX CLOUD SHELL ---
            idLower.contains("termux") || titleLower.contains("termux") || titleLower.contains("terminal") -> {
                TermuxIcon()
            }

            // --- SPEEDTEST 10G ---
            idLower.contains("speedtest") || titleLower.contains("speedtest") -> {
                SpeedtestIcon()
            }

            // --- ANTUTU 3D BENCHMARK ---
            idLower.contains("antutu") || titleLower.contains("antutu") || titleLower.contains("benchmark") -> {
                AnTuTuIcon()
            }

            // --- DISCORD ---
            idLower.contains("discord") || titleLower.contains("discord") -> {
                DiscordIcon()
            }

            // --- SPOTIFY ---
            idLower.contains("spotify") || titleLower.contains("spotify") -> {
                SpotifyIcon()
            }

            // --- DEVICE SPECS / SNAPDRAGON ---
            idLower.contains("specs") || idLower.contains("cpu") || titleLower.contains("specs") -> {
                DeviceSpecsIcon()
            }

            // --- SETTINGS ---
            idLower.contains("settings") || titleLower.contains("settings") -> {
                SettingsIcon()
            }

            // --- PHONE / DIALER ---
            idLower.contains("phone") || idLower.contains("dialer") -> {
                PhoneDialerIcon()
            }

            // --- DEFAULT FALLBACK (Clean Gradient with First Letter) ---
            else -> {
                DefaultAppIcon(title = title, appId = appId)
            }
        }
    }
}

/**
 * Authentic 4-color Google Play Store triangle icon on clean surface.
 */
@Composable
fun GooglePlayStoreIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1E293B)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(34.dp)) {
            val w = size.width
            val h = size.height

            // Coordinates for Google Play triangle
            val pTopLeft = Offset(w * 0.12f, h * 0.08f)
            val pBottomLeft = Offset(w * 0.12f, h * 0.92f)
            val pCenterRight = Offset(w * 0.90f, h * 0.50f)
            val pCenter = Offset(w * 0.52f, h * 0.50f)

            // 1. Cyan/Blue left triangle
            val pathBlue = Path().apply {
                moveTo(pTopLeft.x, pTopLeft.y)
                lineTo(pBottomLeft.x, pBottomLeft.y)
                lineTo(pCenter.x, pCenter.y)
                close()
            }
            drawPath(pathBlue, color = Color(0xFF00C3FF))

            // 2. Green top chevron
            val pathGreen = Path().apply {
                moveTo(pTopLeft.x, pTopLeft.y)
                lineTo(pCenterRight.x, pCenterRight.y)
                lineTo(pCenter.x, pCenter.y)
                close()
            }
            drawPath(pathGreen, color = Color(0xFF00E676))

            // 3. Red right apex
            val pathRed = Path().apply {
                moveTo(w * 0.72f, h * 0.36f)
                lineTo(pCenterRight.x, pCenterRight.y)
                lineTo(w * 0.72f, h * 0.64f)
                close()
            }
            drawPath(pathRed, color = Color(0xFFFF334B))

            // 4. Yellow bottom chevron
            val pathYellow = Path().apply {
                moveTo(pBottomLeft.x, pBottomLeft.y)
                lineTo(pCenterRight.x, pCenterRight.y)
                lineTo(pCenter.x, pCenter.y)
                close()
            }
            drawPath(pathYellow, color = Color(0xFFFFD600))
        }
    }
}

/**
 * Authentic 4-color Google Chrome circular logo.
 */
@Composable
fun GoogleChromeIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(38.dp)) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = size.width / 2f

            // Red segment (top left)
            drawArc(
                color = Color(0xFFEA4335),
                startAngle = -120f,
                sweepAngle = 120f,
                useCenter = true,
                size = size
            )

            // Yellow segment (right)
            drawArc(
                color = Color(0xFFFBBC05),
                startAngle = 0f,
                sweepAngle = 120f,
                useCenter = true,
                size = size
            )

            // Green segment (bottom)
            drawArc(
                color = Color(0xFF34A853),
                startAngle = 120f,
                sweepAngle = 120f,
                useCenter = true,
                size = size
            )

            // White dividing ring
            drawCircle(
                color = Color.White,
                radius = radius * 0.52f,
                center = center
            )

            // Inner Blue circle
            drawCircle(
                color = Color(0xFF4285F4),
                radius = radius * 0.40f,
                center = center
            )
        }
    }
}

/**
 * Authentic 3-color Google Drive folded triangle icon.
 */
@Composable
fun GoogleDriveIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(36.dp)) {
            val w = size.width
            val h = size.height

            // Google Drive 3-color folded ribbon
            // Yellow ribbon (top slant)
            val pathYellow = Path().apply {
                moveTo(w * 0.33f, h * 0.12f)
                lineTo(w * 0.67f, h * 0.12f)
                lineTo(w * 0.48f, h * 0.45f)
                lineTo(w * 0.14f, h * 0.45f)
                close()
            }
            drawPath(pathYellow, color = Color(0xFFFFBA00))

            // Green ribbon (right slant)
            val pathGreen = Path().apply {
                moveTo(w * 0.67f, h * 0.12f)
                lineTo(w * 0.86f, h * 0.45f)
                lineTo(w * 0.52f, h * 0.88f)
                lineTo(w * 0.33f, h * 0.55f)
                close()
            }
            drawPath(pathGreen, color = Color(0xFF00AC47))

            // Blue ribbon (bottom base)
            val pathBlue = Path().apply {
                moveTo(w * 0.14f, h * 0.45f)
                lineTo(w * 0.33f, h * 0.55f)
                lineTo(w * 0.52f, h * 0.88f)
                lineTo(w * 0.18f, h * 0.88f)
                close()
            }
            drawPath(pathBlue, color = Color(0xFF0066DA))
        }
    }
}

/**
 * Authentic YouTube Red badge with white centered play triangle.
 */
@Composable
fun YouTubeIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFF0000)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(22.dp)) {
            val w = size.width
            val h = size.height
            val path = Path().apply {
                moveTo(w * 0.25f, h * 0.12f)
                lineTo(w * 0.88f, h * 0.50f)
                lineTo(w * 0.25f, h * 0.88f)
                close()
            }
            drawPath(path, color = Color.White)
        }
    }
}

/**
 * Authentic Telegram sky blue circle with white folded paper airplane.
 */
@Composable
fun TelegramIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF2AABEE), Color(0xFF229ED9))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(32.dp)) {
            val w = size.width
            val h = size.height

            // Main paper airplane body
            val planeBody = Path().apply {
                moveTo(w * 0.85f, h * 0.18f) // Nose
                lineTo(w * 0.18f, h * 0.52f) // Left wingtip
                lineTo(w * 0.42f, h * 0.65f) // Bottom fold
                lineTo(w * 0.72f, h * 0.32f) // Inner crease
                close()
            }
            drawPath(planeBody, color = Color.White)

            // Right wing & fold shadow
            val planeWing = Path().apply {
                moveTo(w * 0.85f, h * 0.18f)
                lineTo(w * 0.42f, h * 0.65f)
                lineTo(w * 0.56f, h * 0.82f)
                lineTo(w * 0.85f, h * 0.18f)
                close()
            }
            drawPath(planeWing, color = Color(0xFFD2EAF6))
        }
    }
}

/**
 * Authentic VLC Media Player orange traffic cone with reflective stripes.
 */
@Composable
fun VlcPlayerIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1E293B)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(36.dp)) {
            val w = size.width
            val h = size.height

            // Cone base plate
            val basePath = Path().apply {
                moveTo(w * 0.12f, h * 0.82f)
                lineTo(w * 0.88f, h * 0.82f)
                lineTo(w * 0.80f, h * 0.92f)
                lineTo(w * 0.20f, h * 0.92f)
                close()
            }
            drawPath(basePath, color = Color(0xFFE65100))

            // Orange cone body
            val conePath = Path().apply {
                moveTo(w * 0.44f, h * 0.12f)
                lineTo(w * 0.56f, h * 0.12f)
                lineTo(w * 0.76f, h * 0.82f)
                lineTo(w * 0.24f, h * 0.82f)
                close()
            }
            drawPath(conePath, color = Color(0xFFFF6D00))

            // Top reflective white band
            val topBand = Path().apply {
                moveTo(w * 0.40f, h * 0.38f)
                lineTo(w * 0.60f, h * 0.38f)
                lineTo(w * 0.64f, h * 0.50f)
                lineTo(w * 0.36f, h * 0.50f)
                close()
            }
            drawPath(topBand, color = Color.White)

            // Bottom reflective white band
            val botBand = Path().apply {
                moveTo(w * 0.32f, h * 0.60f)
                lineTo(w * 0.68f, h * 0.60f)
                lineTo(w * 0.73f, h * 0.74f)
                lineTo(w * 0.27f, h * 0.74f)
                close()
            }
            drawPath(botBand, color = Color.White)

            // Orange rounded tip
            drawCircle(
                color = Color(0xFFFF8F00),
                radius = w * 0.08f,
                center = Offset(w * 0.50f, h * 0.14f)
            )
        }
    }
}

/**
 * Authentic Termux Linux Cloud Shell terminal icon with >_ prompt.
 */
@Composable
fun TermuxIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF020617)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(34.dp)) {
            val w = size.width
            val h = size.height

            // Terminal prompt: '>'
            val pathChevron = Path().apply {
                moveTo(w * 0.20f, h * 0.28f)
                lineTo(w * 0.48f, h * 0.50f)
                lineTo(w * 0.20f, h * 0.72f)
            }
            drawPath(
                path = pathChevron,
                color = Color(0xFF10B981),
                style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round)
            )

            // Underscore cursor: '_'
            drawLine(
                color = Color(0xFF10B981),
                start = Offset(w * 0.56f, h * 0.72f),
                end = Offset(w * 0.84f, h * 0.72f),
                strokeWidth = 3.5.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}

/**
 * Authentic Speedtest 10G Ultra gauge icon with glowing neon arc and needle.
 */
@Composable
fun SpeedtestIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    listOf(Color(0xFF1E1B4B), Color(0xFF0F172A))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(36.dp)) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = size.width * 0.40f

            // Gauge background arc
            drawArc(
                color = Color(0xFF334155),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )

            // Active glowing speed arc
            drawArc(
                brush = Brush.sweepGradient(
                    listOf(Color(0xFF06B6D4), Color(0xFF3B82F6), Color(0xFF8B5CF6))
                ),
                startAngle = 135f,
                sweepAngle = 220f,
                useCenter = false,
                style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round)
            )

            // Speedometer needle pointing to 10G
            drawLine(
                color = Color(0xFF06B6D4),
                start = center,
                end = Offset(center.x + radius * 0.70f, center.y - radius * 0.70f),
                strokeWidth = 2.5.dp.toPx(),
                cap = StrokeCap.Round
            )

            // Center pivot
            drawCircle(color = Color.White, radius = 3.dp.toPx(), center = center)
        }
    }
}

/**
 * Authentic AnTuTu 3D Cloud Benchmark emblem with high-speed benchmark flame.
 */
@Composable
fun AnTuTuIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFFE11D48), Color(0xFF9F1239))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(34.dp)) {
            val w = size.width
            val h = size.height

            // Dynamic flame crest
            val flame = Path().apply {
                moveTo(w * 0.50f, h * 0.15f)
                cubicTo(w * 0.70f, h * 0.35f, w * 0.85f, h * 0.60f, w * 0.75f, h * 0.82f)
                cubicTo(w * 0.65f, h * 0.95f, w * 0.35f, h * 0.95f, w * 0.25f, h * 0.82f)
                cubicTo(w * 0.15f, h * 0.65f, w * 0.35f, h * 0.45f, w * 0.40f, h * 0.35f)
                cubicTo(w * 0.42f, h * 0.48f, w * 0.55f, h * 0.55f, w * 0.58f, h * 0.42f)
                close()
            }
            drawPath(flame, color = Color.White)

            // Inner golden spark
            val innerFlame = Path().apply {
                moveTo(w * 0.50f, h * 0.52f)
                lineTo(w * 0.62f, h * 0.76f)
                lineTo(w * 0.38f, h * 0.76f)
                close()
            }
            drawPath(innerFlame, color = Color(0xFFFBBF24))
        }
    }
}

/**
 * Authentic Discord Blurple squircle with Clyde game controller mascot.
 */
@Composable
fun DiscordIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF5865F2)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(34.dp)) {
            val w = size.width
            val h = size.height

            // Clyde controller body
            val clyde = Path().apply {
                moveTo(w * 0.20f, h * 0.32f)
                cubicTo(w * 0.35f, h * 0.25f, w * 0.65f, h * 0.25f, w * 0.80f, h * 0.32f)
                lineTo(w * 0.88f, h * 0.68f)
                cubicTo(w * 0.82f, h * 0.76f, w * 0.70f, h * 0.76f, w * 0.64f, h * 0.70f)
                lineTo(w * 0.58f, h * 0.62f)
                lineTo(w * 0.42f, h * 0.62f)
                lineTo(w * 0.36f, h * 0.70f)
                cubicTo(w * 0.30f, h * 0.76f, w * 0.18f, h * 0.76f, w * 0.12f, h * 0.68f)
                close()
            }
            drawPath(clyde, color = Color.White)

            // Left eye
            drawCircle(
                color = Color(0xFF5865F2),
                radius = w * 0.08f,
                center = Offset(w * 0.36f, h * 0.48f)
            )

            // Right eye
            drawCircle(
                color = Color(0xFF5865F2),
                radius = w * 0.08f,
                center = Offset(w * 0.64f, h * 0.48f)
            )
        }
    }
}

/**
 * Authentic Spotify green circle with curved sound waves.
 */
@Composable
fun SpotifyIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1DB954)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(34.dp)) {
            val center = Offset(size.width / 2f, size.height / 2f)

            // 3 sound waves
            drawArc(
                color = Color.Black.copy(alpha = 0.85f),
                startAngle = -150f,
                sweepAngle = 75f,
                useCenter = false,
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round),
                topLeft = Offset(center.x - 12.dp.toPx(), center.y - 10.dp.toPx()),
                size = Size(24.dp.toPx(), 24.dp.toPx())
            )

            drawArc(
                color = Color.Black.copy(alpha = 0.85f),
                startAngle = -150f,
                sweepAngle = 70f,
                useCenter = false,
                style = Stroke(width = 2.8.dp.toPx(), cap = StrokeCap.Round),
                topLeft = Offset(center.x - 9.dp.toPx(), center.y - 5.dp.toPx()),
                size = Size(18.dp.toPx(), 18.dp.toPx())
            )

            drawArc(
                color = Color.Black.copy(alpha = 0.85f),
                startAngle = -150f,
                sweepAngle = 65f,
                useCenter = false,
                style = Stroke(width = 2.4.dp.toPx(), cap = StrokeCap.Round),
                topLeft = Offset(center.x - 6.dp.toPx(), center.y),
                size = Size(12.dp.toPx(), 12.dp.toPx())
            )
        }
    }
}

/**
 * Authentic Device Specs / Snapdragon CPU microchip icon.
 */
@Composable
fun DeviceSpecsIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF4F46E5), Color(0xFF7C3AED))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Memory,
            contentDescription = "Device Specs",
            tint = Color(0xFFFBBF24),
            modifier = Modifier.size(32.dp)
        )
    }
}

/**
 * Authentic Android System Settings gear icon.
 */
@Composable
fun SettingsIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF475569), Color(0xFF1E293B))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Settings,
            contentDescription = "Settings",
            tint = Color.White,
            modifier = Modifier.size(30.dp)
        )
    }
}

/**
 * Authentic Emerald Phone dialer icon.
 */
@Composable
fun PhoneDialerIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF10B981), Color(0xFF059669))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Phone,
            contentDescription = "Phone",
            tint = Color.White,
            modifier = Modifier.size(26.dp)
        )
    }
}

/**
 * Authentic Roblox App Icon.
 * Features the signature tilted silver cube with square hole on sleek dark graphite background.
 */
@Composable
fun RobloxAppIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF1E242B), Color(0xFF0F1216))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(28.dp)) {
            val w = size.width
            val h = size.height

            // Rotate slightly for Roblox iconic 10-degree tilted cube
            drawContext.transform.rotate(degrees = -10f, pivot = center)

            // Outer metallic silver/white square
            val outerSize = w * 0.76f
            val outerTopLeft = Offset((w - outerSize) / 2f, (h - outerSize) / 2f)
            drawRoundRect(
                color = Color(0xFFF1F5F9),
                topLeft = outerTopLeft,
                size = Size(outerSize, outerSize),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx(), 4.dp.toPx())
            )

            // Inner dark square cutout
            val innerSize = outerSize * 0.42f
            val innerTopLeft = Offset((w - innerSize) / 2f, (h - innerSize) / 2f)
            drawRoundRect(
                color = Color(0xFF13171C),
                topLeft = innerTopLeft,
                size = Size(innerSize, innerSize),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx(), 2.dp.toPx())
            )
        }
    }
}

/**
 * Authentic Minecraft 3D Grass Block Icon.
 */
@Composable
fun MinecraftAppIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1F2937)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(36.dp)) {
            val w = size.width
            val h = size.height

            // Dirt block base
            drawRect(
                color = Color(0xFF865538),
                topLeft = Offset(w * 0.1f, h * 0.1f),
                size = Size(w * 0.8f, h * 0.8f)
            )

            // Dirt pixel variations
            drawRect(color = Color(0xFF573D26), topLeft = Offset(w * 0.2f, h * 0.55f), size = Size(w * 0.2f, h * 0.18f))
            drawRect(color = Color(0xFF573D26), topLeft = Offset(w * 0.6f, h * 0.65f), size = Size(w * 0.18f, h * 0.15f))
            drawRect(color = Color(0xFF9E6845), topLeft = Offset(w * 0.45f, h * 0.45f), size = Size(w * 0.15f, h * 0.15f))

            // Lush green grass top layer with pixel drip
            drawRect(color = Color(0xFF5C9E31), topLeft = Offset(w * 0.1f, h * 0.1f), size = Size(w * 0.8f, h * 0.28f))
            drawRect(color = Color(0xFF4C8727), topLeft = Offset(w * 0.2f, h * 0.38f), size = Size(w * 0.15f, h * 0.12f))
            drawRect(color = Color(0xFF4C8727), topLeft = Offset(w * 0.55f, h * 0.38f), size = Size(w * 0.18f, h * 0.15f))
            drawRect(color = Color(0xFF6BB539), topLeft = Offset(w * 0.35f, h * 0.12f), size = Size(w * 0.3f, h * 0.12f))
        }
    }
}

/**
 * Authentic Free Fire MAX Flame Crest Icon.
 */
@Composable
fun FreeFireAppIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    listOf(Color(0xFF7F1D1D), Color(0xFF0F172A))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(32.dp)) {
            val w = size.width
            val h = size.height

            // Fire wing shape
            val path = Path().apply {
                moveTo(w * 0.5f, h * 0.1f)
                cubicTo(w * 0.8f, h * 0.35f, w * 0.9f, h * 0.65f, w * 0.5f, h * 0.9f)
                cubicTo(w * 0.1f, h * 0.65f, w * 0.2f, h * 0.35f, w * 0.5f, h * 0.1f)
                close()
            }
            drawPath(path, brush = Brush.verticalGradient(listOf(Color(0xFFFDE047), Color(0xFFEA580C))))

            val innerPath = Path().apply {
                moveTo(w * 0.5f, h * 0.3f)
                cubicTo(w * 0.7f, h * 0.45f, w * 0.7f, h * 0.7f, w * 0.5f, h * 0.85f)
                cubicTo(w * 0.3f, h * 0.7f, w * 0.3f, h * 0.45f, w * 0.5f, h * 0.3f)
                close()
            }
            drawPath(innerPath, color = Color(0xFFFEF08A))
        }
    }
}

/**
 * Authentic PUBG Mobile Level 3 Helmet Icon.
 */
@Composable
fun PubgAppIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF262626), Color(0xFF0A0A0A))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(32.dp)) {
            val w = size.width
            val h = size.height

            // Helmet Dome
            drawArc(
                color = Color(0xFF404040),
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = true,
                topLeft = Offset(w * 0.15f, h * 0.2f),
                size = Size(w * 0.7f, h * 0.55f)
            )
            // Visor slit
            drawRoundRect(
                color = Color(0xFFEAB308),
                topLeft = Offset(w * 0.25f, h * 0.48f),
                size = Size(w * 0.5f, h * 0.12f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx())
            )
            // Chin guard
            drawRoundRect(
                color = Color(0xFF262626),
                topLeft = Offset(w * 0.22f, h * 0.62f),
                size = Size(w * 0.56f, h * 0.18f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(3.dp.toPx())
            )
        }
    }
}

/**
 * Authentic Call of Duty: Mobile Icon.
 */
@Composable
fun CodMobileAppIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF1E293B), Color(0xFF020617))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(30.dp)) {
            val w = size.width
            val h = size.height

            // Skull forehead
            drawCircle(
                color = Color(0xFFE2E8F0),
                radius = w * 0.28f,
                center = Offset(w * 0.5f, h * 0.42f)
            )
            // Eye sockets
            drawCircle(color = Color(0xFF0F172A), radius = w * 0.08f, center = Offset(w * 0.4f, h * 0.44f))
            drawCircle(color = Color(0xFF0F172A), radius = w * 0.08f, center = Offset(w * 0.6f, h * 0.44f))

            // Jaw
            drawRoundRect(
                color = Color(0xFFCBD5E1),
                topLeft = Offset(w * 0.38f, h * 0.62f),
                size = Size(w * 0.24f, h * 0.18f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx())
            )
        }
    }
}

/**
 * Authentic Genshin Impact Star Icon.
 */
@Composable
fun GenshinAppIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    listOf(Color(0xFF38BDF8), Color(0xFF1E1B4B))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(30.dp)) {
            val w = size.width
            val h = size.height

            val starPath = Path().apply {
                moveTo(w * 0.5f, h * 0.15f)
                lineTo(w * 0.6f, h * 0.42f)
                lineTo(w * 0.88f, h * 0.5f)
                lineTo(w * 0.6f, h * 0.58f)
                lineTo(w * 0.5f, h * 0.85f)
                lineTo(w * 0.4f, h * 0.58f)
                lineTo(w * 0.12f, h * 0.5f)
                lineTo(w * 0.4f, h * 0.42f)
                close()
            }
            drawPath(starPath, brush = Brush.verticalGradient(listOf(Color(0xFFFEF08A), Color(0xFFF59E0B))))
        }
    }
}

/**
 * Authentic Subway Surfers Icon.
 */
@Composable
fun SubwaySurfersAppIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFFF59E0B), Color(0xFFEA580C))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(30.dp)) {
            val w = size.width
            val h = size.height

            // Red cap visor
            drawArc(
                color = Color(0xFFDC2626),
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = true,
                topLeft = Offset(w * 0.15f, h * 0.25f),
                size = Size(w * 0.7f, h * 0.45f)
            )
            drawRoundRect(
                color = Color(0xFF991B1B),
                topLeft = Offset(w * 0.12f, h * 0.45f),
                size = Size(w * 0.76f, h * 0.16f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx())
            )
        }
    }
}

/**
 * Authentic TikTok 3-Color Note Icon on Black.
 */
@Composable
fun TikTokAppIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(30.dp)) {
            val w = size.width
            val h = size.height

            // Cyan offset note
            val notePathCyan = Path().apply {
                moveTo(w * 0.46f, h * 0.28f)
                lineTo(w * 0.64f, h * 0.28f)
                cubicTo(w * 0.64f, h * 0.38f, w * 0.72f, h * 0.46f, w * 0.82f, h * 0.46f)
                lineTo(w * 0.82f, h * 0.58f)
                cubicTo(w * 0.72f, h * 0.58f, w * 0.64f, h * 0.52f, w * 0.64f, h * 0.52f)
                lineTo(w * 0.64f, h * 0.7f)
                cubicTo(w * 0.64f, h * 0.82f, w * 0.52f, h * 0.88f, w * 0.42f, h * 0.86f)
                cubicTo(w * 0.30f, h * 0.82f, w * 0.24f, h * 0.72f, w * 0.28f, h * 0.62f)
                cubicTo(w * 0.32f, h * 0.52f, w * 0.42f, h * 0.50f, w * 0.50f, h * 0.54f)
                lineTo(w * 0.50f, h * 0.28f)
                close()
            }
            drawPath(notePathCyan, color = Color(0xFF25F4EE).copy(alpha = 0.9f))

            // Magenta offset note
            drawContext.transform.translate(left = 2f, top = 2f)
            drawPath(notePathCyan, color = Color(0xFFFE2C55).copy(alpha = 0.9f))
            drawContext.transform.translate(left = -2f, top = -2f)

            // Pure white center
            drawPath(notePathCyan, color = Color.White)
        }
    }
}

/**
 * Authentic Instagram Gradient Camera Icon.
 */
@Composable
fun InstagramAppIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(0xFF833AB4),
                        Color(0xFFFD1D1D),
                        Color(0xFFFCB045)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(30.dp)) {
            val w = size.width
            val h = size.height

            // Outer rounded square
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(w * 0.15f, h * 0.15f),
                size = Size(w * 0.7f, h * 0.7f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(8.dp.toPx()),
                style = Stroke(width = 3.dp.toPx())
            )
            // Center camera circle
            drawCircle(
                color = Color.White,
                radius = w * 0.18f,
                center = center,
                style = Stroke(width = 3.dp.toPx())
            )
            // Top right flash dot
            drawCircle(
                color = Color.White,
                radius = 2.dp.toPx(),
                center = Offset(w * 0.68f, h * 0.32f)
            )
        }
    }
}

/**
 * Authentic WhatsApp Messenger Icon.
 */
@Composable
fun WhatsAppAppIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF25D366), Color(0xFF128C7E))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Phone,
            contentDescription = "WhatsApp",
            tint = Color.White,
            modifier = Modifier.size(28.dp)
        )
    }
}

/**
 * Authentic Facebook 'f' Logo Icon.
 */
@Composable
fun FacebookAppIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1877F2)),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Text(
            text = "f",
            color = Color.White,
            fontSize = 34.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.padding(bottom = 4.dp)
        )
    }
}

/**
 * Authentic Netflix Red 'N' Icon.
 */
@Composable
fun NetflixAppIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Text(
            text = "N",
            color = Color(0xFFE50914),
            fontSize = 32.sp,
            fontWeight = FontWeight.ExtraBold
        )
    }
}

/**
 * Authentic X (Twitter) Minimalist Black Icon.
 */
@Composable
fun XTwitterAppIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Text(
            text = "𝕏",
            color = Color.White,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

/**
 * Upgraded premium fallback icon:
 * Dynamically styled with brand color gradients and clean modern glassmorphic surface.
 */
@Composable
fun DefaultAppIcon(title: String, appId: String = "") {
    val hash = (appId.ifEmpty { title }).hashCode()
    val gradients = listOf(
        listOf(Color(0xFF2563EB), Color(0xFF1D4ED8)),
        listOf(Color(0xFF7C3AED), Color(0xFF5B21B6)),
        listOf(Color(0xFF059669), Color(0xFF047857)),
        listOf(Color(0xFFD97706), Color(0xFFB45309)),
        listOf(Color(0xFFDC2626), Color(0xFF991B1B)),
        listOf(Color(0xFF0891B2), Color(0xFF0E7490)),
        listOf(Color(0xFFBE185D), Color(0xFF9D174D))
    )
    val colorPair = gradients[kotlin.math.abs(hash % gradients.size)]

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.linearGradient(colorPair)),
        contentAlignment = Alignment.Center
    ) {
        // Subtle inner glow
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(2.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.White.copy(alpha = 0.08f)),
            contentAlignment = Alignment.Center
        ) {
            val letter = if (title.isNotBlank()) title.trim().take(1).uppercase() else "A"
            androidx.compose.material3.Text(
                text = letter,
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold
            )
        }
    }
}

