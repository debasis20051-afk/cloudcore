package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.local.SpeedtestRecordEntity
import com.example.model.CloudDevice
import com.example.model.CloudWindow
import com.example.model.PlayApp
import com.example.ui.components.CloudFloatingBall
import com.example.ui.components.KeymappingOverlay
import com.example.ui.components.VirtualStatusBar
import com.example.ui.theme.DarkBg
import com.example.viewmodel.CloudPhoneUiState

@Composable
fun CloudPhoneScreen(
    uiState: CloudPhoneUiState,
    playApps: List<PlayApp>,
    speedtestHistory: List<SpeedtestRecordEntity>,
    onNavigateWindow: (CloudWindow) -> Unit,
    onGoHome: () -> Unit,
    onToggleDrawer: (Boolean) -> Unit,
    onToggleKeymapping: () -> Unit,
    onToggleAfk: () -> Unit,
    onInstallApp: (String) -> Unit,
    onUninstallApp: (String) -> Unit,
    onSelectPlayCategory: (String) -> Unit,
    onPlaySearchChange: (String) -> Unit,
    onChromeNavigate: (String) -> Unit,
    onChromeNewTab: () -> Unit,
    onInstallCustomApk: (title: String, packageName: String, developer: String, category: String, sizeMb: Int, isGame: Boolean, accentHex: Long) -> Unit = { _, _, _, _, _, _, _ -> },
    onLaunchApp: (PlayApp) -> Unit = {},
    onStartSpeedtest: () -> Unit,
    onToggleRoot: () -> Unit,
    onSetQuality: (com.example.model.StreamQuality) -> Unit,
    onSetLocation: (String) -> Unit,
    onReboot: () -> Unit,
    onExitToDashboard: () -> Unit,
    onGoogleLoginClick: () -> Unit = {},
    onToggleRunWhenPhoneOff: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    // Android hardware back handler: navigates back to Home or exits
    BackHandler(enabled = uiState.currentWindow != CloudWindow.HOME_LAUNCHER) {
        onGoHome()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Android 15 Virtual Status Bar
            VirtualStatusBar(
                device = uiState.activeDevice,
                pingMs = uiState.streamPingMs,
                fps = uiState.streamFps
            )

            // Dynamic Window Content
            Box(modifier = Modifier.weight(1f)) {
                AnimatedContent(
                    targetState = uiState.currentWindow,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "windowTransition"
                ) { targetWindow ->
                    when (targetWindow) {
                        CloudWindow.HOME_LAUNCHER -> {
                            DesktopLauncherScreen(
                                device = uiState.activeDevice,
                                installedApps = playApps.filter { it.isInstalled },
                                googleUser = uiState.googleUser,
                                runWhenPhoneOff = uiState.runWhenPhoneOff,
                                onLaunchWindow = onNavigateWindow,
                                onLaunchApp = onLaunchApp,
                                showDrawer = uiState.showAppDrawer,
                                onToggleDrawer = onToggleDrawer,
                                onGoogleAccountClick = onGoogleLoginClick
                            )
                        }
                        CloudWindow.GOOGLE_PLAY_STORE -> {
                            PlayStoreScreen(
                                apps = playApps,
                                selectedCategory = uiState.playStoreCategory,
                                onSelectCategory = onSelectPlayCategory,
                                searchQuery = uiState.searchQuery,
                                onSearchQueryChange = onPlaySearchChange,
                                onInstallApp = onInstallApp,
                                onUninstallApp = onUninstallApp,
                                onLaunchApp = onLaunchApp,
                                onClosePlayStore = onGoHome,
                                googleUser = uiState.googleUser,
                                onGoogleLoginClick = onGoogleLoginClick,
                                onInstallCustomApk = onInstallCustomApk
                            )
                        }
                        CloudWindow.CHROME_BROWSER -> {
                            ChromeScreen(
                                currentUrl = uiState.chromeUrl,
                                onNavigateUrl = onChromeNavigate,
                                onCloseBrowser = onGoHome,
                                tabsCount = uiState.chromeTabsCount,
                                onNewTab = onChromeNewTab,
                                onInstallCustomApk = onInstallCustomApk,
                                onLaunchApp = onLaunchApp,
                                installedApps = playApps
                            )
                        }
                        CloudWindow.SPEEDTEST -> {
                            SpeedtestScreen(
                                device = uiState.activeDevice,
                                isTesting = uiState.isTestingSpeed,
                                phase = uiState.speedtestPhase,
                                downloadMbps = uiState.currentDownloadSpeedMbps,
                                uploadMbps = uiState.currentUploadSpeedMbps,
                                history = speedtestHistory,
                                onStartTest = onStartSpeedtest,
                                onClose = onGoHome
                            )
                        }
                        CloudWindow.DEVICE_SPECS -> {
                            DeviceSpecsScreen(
                                device = uiState.activeDevice,
                                onToggleRoot = onToggleRoot,
                                onClose = onGoHome
                            )
                        }
                        CloudWindow.RUNNING_APP -> {
                            val activeApp = uiState.currentRunningApp
                            if (activeApp != null) {
                                RunningAppScreen(
                                    app = activeApp,
                                    device = uiState.activeDevice,
                                    onClose = onGoHome
                                )
                            } else {
                                onGoHome()
                            }
                        }
                        CloudWindow.CLOUD_SETTINGS -> {
                            CloudSettingsScreen(
                                device = uiState.activeDevice,
                                googleUser = uiState.googleUser,
                                runWhenPhoneOff = uiState.runWhenPhoneOff,
                                onToggleRunWhenPhoneOff = onToggleRunWhenPhoneOff,
                                onGoogleLoginClick = onGoogleLoginClick,
                                onToggleRoot = onToggleRoot,
                                onSetQuality = onSetQuality,
                                onSetLocation = onSetLocation,
                                onReboot = onReboot,
                                onClose = onGoHome
                            )
                        }
                    }
                }

                if (uiState.showKeymappingOverlay) {
                    KeymappingOverlay(
                        isVisible = uiState.showKeymappingOverlay,
                        onActionTap = { _ -> }
                    )
                }
            }
        }

        // High-Tech Cybernetic Floating Ball replacing fixed slide bar
        CloudFloatingBall(
            pingMs = uiState.streamPingMs,
            fps = uiState.streamFps,
            isAfkActive = uiState.isAfkMacroActive,
            isKeymappingActive = uiState.showKeymappingOverlay,
            runningApps = playApps.filter { it.isInstalled },
            onHomeClick = onGoHome,
            onBackClick = onGoHome,
            onExitClick = {
                if (uiState.currentWindow != CloudWindow.HOME_LAUNCHER) {
                    onGoHome()
                } else {
                    onExitToDashboard()
                }
            },
            onToggleKeymapping = onToggleKeymapping,
            onToggleAfk = onToggleAfk,
            onSpeedtestClick = { onNavigateWindow(CloudWindow.SPEEDTEST) },
            onSettingsClick = { onNavigateWindow(CloudWindow.CLOUD_SETTINGS) },
            onFleetClick = onExitToDashboard,
            onInstallUploadedApk = onInstallCustomApk,
            onLaunchApp = onLaunchApp,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 12.dp, bottom = 40.dp)
        )
    }
}
