package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CloudAmber
import com.example.ui.theme.CloudCyan
import com.example.ui.theme.CloudEmerald
import com.example.ui.theme.CloudRose

@Composable
fun KeymappingOverlay(
    isVisible: Boolean,
    onActionTap: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = isVisible,
        enter = fadeIn(),
        exit = fadeOut(),
        modifier = modifier.fillMaxSize()
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Left D-Pad / WASD
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = 24.dp, bottom = 48.dp)
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.35f))
                    .border(1.5.dp, CloudCyan.copy(alpha = 0.4f), CircleShape)
            ) {
                // Directional labels
                Text(
                    "W",
                    color = CloudCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp)
                )
                Text(
                    "S",
                    color = CloudCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp)
                )
                Text(
                    "A",
                    color = CloudCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.CenterStart).padding(start = 8.dp)
                )
                Text(
                    "D",
                    color = CloudCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.CenterEnd).padding(end = 8.dp)
                )
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .align(Alignment.Center)
                        .clip(CircleShape)
                        .background(CloudCyan.copy(alpha = 0.5f))
                )
            }

            // Right ABXY Action Diamond
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 24.dp, bottom = 48.dp)
                    .size(130.dp)
            ) {
                // Y (Top)
                KeymapButton(
                    label = "Y",
                    color = CloudAmber,
                    modifier = Modifier.align(Alignment.TopCenter),
                    onClick = { onActionTap("Y") }
                )
                // A (Bottom)
                KeymapButton(
                    label = "A",
                    color = CloudEmerald,
                    modifier = Modifier.align(Alignment.BottomCenter),
                    onClick = { onActionTap("A") }
                )
                // X (Left)
                KeymapButton(
                    label = "X",
                    color = CloudCyan,
                    modifier = Modifier.align(Alignment.CenterStart),
                    onClick = { onActionTap("X") }
                )
                // B (Right)
                KeymapButton(
                    label = "B",
                    color = CloudRose,
                    modifier = Modifier.align(Alignment.CenterEnd),
                    onClick = { onActionTap("B") }
                )
            }
        }
    }
}

@Composable
private fun KeymapButton(
    label: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.6f))
            .border(1.5.dp, color, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = color,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
