package com.example.ui.screens

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GoogleUserProfile
import com.example.model.PlayApp
import com.example.ui.components.RealAppIcon
import com.example.ui.theme.CloudCyan
import com.example.ui.theme.CloudEmerald
import com.example.ui.theme.CloudViolet
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.PlayGreen
import com.example.util.AppMetadataResolver

enum class PlayStoreBottomTab {
    GAMES,
    APPS,
    SEARCH,
    OFFERS,
    BOOKS
}

/**
 * Authentic, 100% Native Google Play Store Android Application.
 * Replaces any web view with the real Google Play Android client interface:
 * - Iconic Google Play Search Bar with Voice Mic & Google Profile Avatar
 * - Top Category Tabs ("For you", "Top charts", "Kids", "Categories")
 * - Bottom Navigation Tabs (Games, Apps, Search, Offers, Books)
 * - Hero Featured Carousels & Highlights
 * - Top Charts with Ranking (#1, #2, #3...)
 * - Complete Google Play App Details Page with Ratings, Reviews, Screenshots & Install
 * - Instant 10G Cloud Phone installation and direct phone APK download via Google Play
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayStoreScreen(
    apps: List<PlayApp>,
    selectedCategory: String,
    onSelectCategory: (String) -> Unit,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onInstallApp: (String) -> Unit,
    onUninstallApp: (String) -> Unit,
    onLaunchApp: (PlayApp) -> Unit,
    onClosePlayStore: () -> Unit,
    googleUser: GoogleUserProfile? = null,
    onGoogleLoginClick: () -> Unit = {},
    onInstallCustomApk: (title: String, packageName: String, developer: String, category: String, sizeMb: Int, isGame: Boolean, accentHex: Long) -> Unit = { _, _, _, _, _, _, _ -> },
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var currentBottomTab by remember { mutableStateOf(PlayStoreBottomTab.GAMES) }
    var selectedTopTab by remember { mutableIntStateOf(0) }
    var selectedAppDetail by remember { mutableStateOf<PlayApp?>(null) }
    var isSearchActive by remember { mutableStateOf(false) }

    val topTabs = listOf("For you", "Top charts", "Kids", "Categories", "Premium")

    // Handle back button
    BackHandler {
        if (selectedAppDetail != null) {
            selectedAppDetail = null
        } else if (isSearchActive) {
            isSearchActive = false
            onSearchQueryChange("")
        } else {
            onClosePlayStore()
        }
    }

    // If an app details page is selected, display the full native Google Play App Page!
    if (selectedAppDetail != null) {
        val currentApp = apps.find { it.id == selectedAppDetail!!.id } ?: selectedAppDetail!!
        PlayStoreAppDetailView(
            app = currentApp,
            onBack = { selectedAppDetail = null },
            onInstall = {
                onInstallApp(currentApp.id)
            },
            onUninstall = {
                onUninstallApp(currentApp.id)
            },
            onLaunch = {
                onLaunchApp(currentApp)
            },
            modifier = modifier
        )
        return
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        // --- 1. GOOGLE PLAY TOP BAR WITH SEARCH PILL ---
        Surface(
            color = DarkSurface,
            tonalElevation = 4.dp,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                // Search Pill Container
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(DarkSurfaceElevated)
                        .border(1.dp, DarkCardBorder, RoundedCornerShape(24.dp))
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Back / Close button
                    IconButton(
                        onClick = {
                            if (isSearchActive) {
                                isSearchActive = false
                                onSearchQueryChange("")
                            } else {
                                onClosePlayStore()
                            }
                        },
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.LightGray,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Search input
                    Box(modifier = Modifier.weight(1f).padding(horizontal = 6.dp)) {
                        if (searchQuery.isEmpty()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = null,
                                    tint = PlayGreen,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Search apps & games",
                                    color = Color.Gray,
                                    fontSize = 14.sp
                                )
                            }
                        }
                        androidx.compose.foundation.text.BasicTextField(
                            value = searchQuery,
                            onValueChange = {
                                onSearchQueryChange(it)
                                if (it.isNotEmpty()) isSearchActive = true
                            },
                            textStyle = androidx.compose.ui.text.TextStyle(
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Normal
                            ),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("play_store_search_input")
                        )
                    }

                    if (searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = { onSearchQueryChange("") },
                            modifier = Modifier.size(30.dp)
                        ) {
                            Icon(Icons.Default.Close, null, tint = Color.LightGray, modifier = Modifier.size(16.dp))
                        }
                    } else {
                        // Voice Mic Icon
                        IconButton(
                            onClick = {
                                Toast.makeText(context, "Voice Search Active", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(30.dp)
                        ) {
                            Icon(Icons.Default.Mic, null, tint = Color.LightGray, modifier = Modifier.size(18.dp))
                        }
                    }

                    // Google Account Profile Avatar
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(
                                if (googleUser?.isSignedIn == true) Brush.linearGradient(listOf(CloudCyan, CloudViolet))
                                else Brush.linearGradient(listOf(PlayGreen, Color(0xFF02569B)))
                            )
                            .clickable(onClick = onGoogleLoginClick)
                            .testTag("play_store_profile_avatar"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = googleUser?.avatarInitial ?: "D",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Top Category Tabs (Only when not in full search mode)
                if (!isSearchActive && currentBottomTab != PlayStoreBottomTab.OFFERS) {
                    Spacer(modifier = Modifier.height(6.dp))
                    ScrollableTabRow(
                        selectedTabIndex = selectedTopTab,
                        edgePadding = 4.dp,
                        containerColor = DarkSurface,
                        contentColor = PlayGreen,
                        indicator = { tabPositions ->
                            if (selectedTopTab < tabPositions.size) {
                                TabRowDefaults.SecondaryIndicator(
                                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTopTab]),
                                    height = 3.dp,
                                    color = PlayGreen
                                )
                            }
                        },
                        divider = {}
                    ) {
                        topTabs.forEachIndexed { index, tabName ->
                            Tab(
                                selected = selectedTopTab == index,
                                onClick = { selectedTopTab = index },
                                text = {
                                    Text(
                                        text = tabName,
                                        fontSize = 13.sp,
                                        fontWeight = if (selectedTopTab == index) FontWeight.Bold else FontWeight.Normal,
                                        color = if (selectedTopTab == index) PlayGreen else Color.LightGray
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }

        // --- 2. MAIN STORE CONTENT VIEWPORT ---
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (isSearchActive || searchQuery.isNotEmpty()) {
                // Live Search Results
                PlayStoreSearchResultsView(
                    apps = apps,
                    query = searchQuery,
                    onAppClick = { selectedAppDetail = it },
                    onInstallApp = onInstallApp,
                    onLaunchApp = onLaunchApp
                )
            } else {
                when (currentBottomTab) {
                    PlayStoreBottomTab.GAMES -> {
                        when (selectedTopTab) {
                            1 -> PlayStoreTopChartsView(
                                apps = apps.filter { it.isGame },
                                onAppClick = { selectedAppDetail = it },
                                onInstallApp = onInstallApp,
                                onLaunchApp = onLaunchApp
                            )
                            else -> PlayStoreCatalogView(
                                apps = apps.filter { it.isGame },
                                isGamesTab = true,
                                onAppClick = { selectedAppDetail = it },
                                onInstallApp = onInstallApp,
                                onLaunchApp = onLaunchApp
                            )
                        }
                    }
                    PlayStoreBottomTab.APPS -> {
                        when (selectedTopTab) {
                            1 -> PlayStoreTopChartsView(
                                apps = apps.filter { !it.isGame },
                                onAppClick = { selectedAppDetail = it },
                                onInstallApp = onInstallApp,
                                onLaunchApp = onLaunchApp
                            )
                            else -> PlayStoreCatalogView(
                                apps = apps.filter { !it.isGame },
                                isGamesTab = false,
                                onAppClick = { selectedAppDetail = it },
                                onInstallApp = onInstallApp,
                                onLaunchApp = onLaunchApp
                            )
                        }
                    }
                    PlayStoreBottomTab.SEARCH -> {
                        PlayStoreSearchResultsView(
                            apps = apps,
                            query = searchQuery,
                            onAppClick = { selectedAppDetail = it },
                            onInstallApp = onInstallApp,
                            onLaunchApp = onLaunchApp
                        )
                    }
                    PlayStoreBottomTab.OFFERS -> {
                        PlayStoreOffersView(
                            onExploreApp = { pkg ->
                                val match = apps.find { it.id == pkg }
                                if (match != null) selectedAppDetail = match
                            }
                        )
                    }
                    PlayStoreBottomTab.BOOKS -> {
                        PlayStoreBooksView()
                    }
                }
            }
        }

        // --- 3. GOOGLE PLAY BOTTOM NAVIGATION BAR ---
        NavigationBar(
            containerColor = DarkSurface,
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth().height(64.dp)
        ) {
            NavigationBarItem(
                selected = currentBottomTab == PlayStoreBottomTab.GAMES && !isSearchActive,
                onClick = {
                    currentBottomTab = PlayStoreBottomTab.GAMES
                    isSearchActive = false
                },
                icon = {
                    Icon(Icons.Default.SportsEsports, contentDescription = "Games", modifier = Modifier.size(20.dp))
                },
                label = { Text("Games", fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = PlayGreen,
                    selectedTextColor = PlayGreen,
                    indicatorColor = PlayGreen.copy(alpha = 0.18f),
                    unselectedIconColor = Color.LightGray,
                    unselectedTextColor = Color.LightGray
                )
            )

            NavigationBarItem(
                selected = currentBottomTab == PlayStoreBottomTab.APPS && !isSearchActive,
                onClick = {
                    currentBottomTab = PlayStoreBottomTab.APPS
                    isSearchActive = false
                },
                icon = {
                    Icon(Icons.Default.Apps, contentDescription = "Apps", modifier = Modifier.size(20.dp))
                },
                label = { Text("Apps", fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = PlayGreen,
                    selectedTextColor = PlayGreen,
                    indicatorColor = PlayGreen.copy(alpha = 0.18f),
                    unselectedIconColor = Color.LightGray,
                    unselectedTextColor = Color.LightGray
                )
            )

            NavigationBarItem(
                selected = isSearchActive || currentBottomTab == PlayStoreBottomTab.SEARCH,
                onClick = {
                    currentBottomTab = PlayStoreBottomTab.SEARCH
                    isSearchActive = true
                },
                icon = {
                    Icon(Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(20.dp))
                },
                label = { Text("Search", fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = PlayGreen,
                    selectedTextColor = PlayGreen,
                    indicatorColor = PlayGreen.copy(alpha = 0.18f),
                    unselectedIconColor = Color.LightGray,
                    unselectedTextColor = Color.LightGray
                )
            )

            NavigationBarItem(
                selected = currentBottomTab == PlayStoreBottomTab.OFFERS && !isSearchActive,
                onClick = {
                    currentBottomTab = PlayStoreBottomTab.OFFERS
                    isSearchActive = false
                },
                icon = {
                    Icon(Icons.Default.LocalOffer, contentDescription = "Offers", modifier = Modifier.size(20.dp))
                },
                label = { Text("Offers", fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = PlayGreen,
                    selectedTextColor = PlayGreen,
                    indicatorColor = PlayGreen.copy(alpha = 0.18f),
                    unselectedIconColor = Color.LightGray,
                    unselectedTextColor = Color.LightGray
                )
            )

            NavigationBarItem(
                selected = currentBottomTab == PlayStoreBottomTab.BOOKS && !isSearchActive,
                onClick = {
                    currentBottomTab = PlayStoreBottomTab.BOOKS
                    isSearchActive = false
                },
                icon = {
                    Icon(Icons.Default.Book, contentDescription = "Books", modifier = Modifier.size(20.dp))
                },
                label = { Text("Books", fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = PlayGreen,
                    selectedTextColor = PlayGreen,
                    indicatorColor = PlayGreen.copy(alpha = 0.18f),
                    unselectedIconColor = Color.LightGray,
                    unselectedTextColor = Color.LightGray
                )
            )
        }
    }
}

/**
 * Main Catalog Stream View (Hero Featured Banner + Horizontal Carousels + Suggested Rows)
 */
@Composable
private fun PlayStoreCatalogView(
    apps: List<PlayApp>,
    isGamesTab: Boolean,
    onAppClick: (PlayApp) -> Unit,
    onInstallApp: (String) -> Unit,
    onLaunchApp: (PlayApp) -> Unit
) {
    val context = LocalContext.current
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // --- 1. HERO FEATURED PROMO BANNER ---
        item {
            Spacer(modifier = Modifier.height(10.dp))
            val featuredApp = if (isGamesTab) {
                apps.find { it.id == "com.roblox.client" } ?: apps.firstOrNull()
            } else {
                apps.find { it.id == "com.zhiliaoapp.musically" } ?: apps.firstOrNull()
            }

            if (featuredApp != null) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                    border = androidx.compose.foundation.BorderStroke(1.dp, PlayGreen.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onAppClick(featuredApp) }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RealAppIcon(
                                appId = featuredApp.id,
                                title = featuredApp.title,
                                size = 52.dp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        color = PlayGreen.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = featuredApp.badge ?: "Featured",
                                            color = PlayGreen,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "10G Cloud Ready",
                                        color = CloudEmerald,
                                        fontSize = 10.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = featuredApp.title,
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${featuredApp.developer} • ${featuredApp.category}",
                                    color = Color.LightGray,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = featuredApp.description,
                            color = Color(0xFFD1D5DB),
                            fontSize = 12.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${featuredApp.rating}",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Icon(Icons.Default.Star, null, tint = Color(0xFFFBBF24), modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "${featuredApp.sizeMb} MB",
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                            }

                            if (featuredApp.isInstalled) {
                                Button(
                                    onClick = {
                                        val isNative = checkIfAppInstalled(context, featuredApp.id)
                                        if (isNative) {
                                            val launchIntent = context.packageManager.getLaunchIntentForPackage(featuredApp.id)
                                            if (launchIntent != null) {
                                                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                context.startActivity(launchIntent)
                                                Toast.makeText(context, "Opening native ${featuredApp.title}...", Toast.LENGTH_SHORT).show()
                                                return@Button
                                            }
                                        }
                                        onLaunchApp(featuredApp)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = PlayGreen),
                                    shape = RoundedCornerShape(18.dp),
                                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Icon(Icons.Default.PlayArrow, null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Play", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            } else {
                                Button(
                                    onClick = {
                                        onInstallApp(featuredApp.id)
                                        launchRealAppOrPlayStore(context, featuredApp.id)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = PlayGreen),
                                    shape = RoundedCornerShape(18.dp),
                                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Icon(Icons.Default.Download, null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Install", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- 2. "RECOMMENDED FOR YOU" SECTION (Horizontal Carousel) ---
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isGamesTab) "Recommended games" else "Suggested for you",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "More",
                        color = PlayGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(apps.take(8)) { app ->
                        Column(
                            modifier = Modifier
                                .width(96.dp)
                                .clickable { onAppClick(app) },
                            horizontalAlignment = Alignment.Start
                        ) {
                            RealAppIcon(
                                appId = app.id,
                                title = app.title,
                                size = 84.dp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = app.title,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${app.rating}",
                                    color = Color.LightGray,
                                    fontSize = 11.sp
                                )
                                Icon(Icons.Default.Star, null, tint = Color(0xFFFBBF24), modifier = Modifier.size(11.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${app.sizeMb}MB",
                                    color = Color.Gray,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- 3. "POPULAR ON 10G CLOUD" VERTICAL LIST ITEMS ---
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = if (isGamesTab) "Trending games this week" else "Top productivity apps",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))
            }
        }

        items(apps.drop(1).take(10)) { app ->
            PlayStoreRowItem(
                app = app,
                onClick = { onAppClick(app) },
                onInstall = { onInstallApp(app.id) },
                onLaunch = { onLaunchApp(app) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

/**
 * Top Charts Tab View: Authentic Ranked #1, #2, #3 list!
 */
@Composable
private fun PlayStoreTopChartsView(
    apps: List<PlayApp>,
    onAppClick: (PlayApp) -> Unit,
    onInstallApp: (String) -> Unit,
    onLaunchApp: (PlayApp) -> Unit
) {
    val context = LocalContext.current
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = PlayGreen.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, PlayGreen)
                ) {
                    Text(
                        text = "Top free",
                        color = PlayGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
                Surface(
                    color = DarkSurfaceElevated,
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
                ) {
                    Text(
                        text = "Top grossing",
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
                Surface(
                    color = DarkSurfaceElevated,
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
                ) {
                    Text(
                        text = "Top paid",
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        itemsIndexed(apps) { index, app ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onAppClick(app) }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Rank number
                Text(
                    text = "${index + 1}",
                    color = if (index < 3) PlayGreen else Color.LightGray,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.width(28.dp)
                )

                RealAppIcon(
                    appId = app.id,
                    title = app.title,
                    size = 54.dp
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = app.title,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${app.developer} • ${app.category}",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        maxLines = 1
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${app.rating}",
                            color = Color.LightGray,
                            fontSize = 11.sp
                        )
                        Icon(Icons.Default.Star, null, tint = Color(0xFFFBBF24), modifier = Modifier.size(11.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${app.sizeMb} MB",
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                if (app.isInstalling) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = PlayGreen,
                        strokeWidth = 2.dp
                    )
                } else if (app.isInstalled) {
                    OutlinedButton(
                        onClick = {
                            val isNative = checkIfAppInstalled(context, app.id)
                            if (isNative) {
                                val launchIntent = context.packageManager.getLaunchIntentForPackage(app.id)
                                if (launchIntent != null) {
                                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    context.startActivity(launchIntent)
                                    Toast.makeText(context, "Opening native ${app.title}...", Toast.LENGTH_SHORT).show()
                                    return@OutlinedButton
                                }
                            }
                            onLaunchApp(app)
                        },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = PlayGreen),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text("Play", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = {
                            onInstallApp(app.id)
                            launchRealAppOrPlayStore(context, app.id)
                        },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
                        border = androidx.compose.foundation.BorderStroke(1.dp, PlayGreen.copy(alpha = 0.5f)),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text("Install", color = PlayGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/**
 * Live Search Results View
 */
@Composable
private fun PlayStoreSearchResultsView(
    apps: List<PlayApp>,
    query: String,
    onAppClick: (PlayApp) -> Unit,
    onInstallApp: (String) -> Unit,
    onLaunchApp: (PlayApp) -> Unit
) {
    val filtered = remember(query, apps) {
        if (query.isBlank()) {
            apps
        } else {
            apps.filter {
                it.title.contains(query, ignoreCase = true) ||
                        it.developer.contains(query, ignoreCase = true) ||
                        it.category.contains(query, ignoreCase = true) ||
                        it.id.contains(query, ignoreCase = true)
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (query.isBlank()) "Popular searches" else "Search results for \"$query\" (${filtered.size})",
                color = Color.LightGray,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        if (filtered.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 40.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Search, null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No apps found for \"$query\"",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Try searching for Roblox, Minecraft, TikTok, Discord, or Subway Surfers",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            items(filtered) { app ->
                PlayStoreRowItem(
                    app = app,
                    onClick = { onAppClick(app) },
                    onInstall = { onInstallApp(app.id) },
                    onLaunch = { onLaunchApp(app) }
                )
            }
        }
    }
}

/**
 * Standard Play Store Row Item with squircle icon, title, rating, and install button
 */
@Composable
private fun PlayStoreRowItem(
    app: PlayApp,
    onClick: () -> Unit,
    onInstall: () -> Unit,
    onLaunch: () -> Unit
) {
    val context = LocalContext.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RealAppIcon(
            appId = app.id,
            title = app.title,
            size = 54.dp
        )

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = app.title,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${app.developer} • ${app.category}",
                color = Color.Gray,
                fontSize = 11.sp,
                maxLines = 1
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${app.rating}",
                    color = Color.LightGray,
                    fontSize = 11.sp
                )
                Icon(Icons.Default.Star, null, tint = Color(0xFFFBBF24), modifier = Modifier.size(11.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${app.sizeMb} MB",
                    color = Color.Gray,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.width(8.dp))

        if (app.isInstalling) {
            CircularProgressIndicator(
                modifier = Modifier.size(24.dp),
                color = PlayGreen,
                strokeWidth = 2.dp
            )
        } else if (app.isInstalled) {
            Button(
                onClick = {
                    val isNative = checkIfAppInstalled(context, app.id)
                    if (isNative) {
                        val launchIntent = context.packageManager.getLaunchIntentForPackage(app.id)
                        if (launchIntent != null) {
                            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(launchIntent)
                            Toast.makeText(context, "Opening native ${app.title}...", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                    }
                    onLaunch()
                },
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PlayGreen),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Text("Play", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        } else {
            Button(
                onClick = {
                    onInstall()
                    launchRealAppOrPlayStore(context, app.id)
                },
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, PlayGreen.copy(alpha = 0.5f)),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Text("Install", color = PlayGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * Authentic Google Play App Detail Screen:
 * Large Icon, Title, Developer in PlayGreen, 3-Column Stats, Big Green Install button,
 * Phone Google Play Store install button, Screenshots preview, About this app, Ratings & reviews.
 */
@Composable
private fun PlayStoreAppDetailView(
    app: PlayApp,
    onBack: () -> Unit,
    onInstall: () -> Unit,
    onUninstall: () -> Unit,
    onLaunch: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isNativeInstalled = remember(app.id) { checkIfAppInstalled(context, app.id) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        // Top App Bar
        Surface(
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Google Play",
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = {
                    val sendIntent = Intent().apply {
                        action = Intent.ACTION_SEND
                        putExtra(Intent.EXTRA_TEXT, "Check out ${app.title} on Google Play: https://play.google.com/store/apps/details?id=${app.id}")
                        type = "text/plain"
                    }
                    context.startActivity(Intent.createChooser(sendIntent, "Share ${app.title}"))
                }) {
                    Icon(Icons.Default.Share, contentDescription = "Share", tint = Color.LightGray)
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(10.dp))
                // App Header: Icon + Title + Dev + Badges
                Row(modifier = Modifier.fillMaxWidth()) {
                    RealAppIcon(
                        appId = app.id,
                        title = app.title,
                        size = 72.dp
                    )

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = app.title,
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = app.developer,
                            color = PlayGreen,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Contains ads • In-app purchases",
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // 3-Column Stats Row (Ratings, Downloads, Age Rating)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DarkSurfaceElevated)
                        .padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${app.rating}",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(Icons.Default.Star, null, tint = Color(0xFFFBBF24), modifier = Modifier.size(13.dp))
                        }
                        Text(text = app.reviews, color = Color.Gray, fontSize = 10.sp)
                    }

                    Box(modifier = Modifier.width(1.dp).height(24.dp).background(DarkCardBorder))

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = app.downloads,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(text = "Downloads", color = Color.Gray, fontSize = 10.sp)
                    }

                    Box(modifier = Modifier.width(1.dp).height(24.dp).background(DarkCardBorder))

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Surface(
                            color = DarkCardBorder,
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text(
                                text = if (app.isGame) "Teen" else "Everyone",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                        Text(text = "Rated for 12+", color = Color.Gray, fontSize = 10.sp)
                    }
                }
            }

            // Primary Action Buttons
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (app.isInstalling) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(DarkSurfaceElevated)
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Downloading & Installing...",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${(app.installProgress * 100).toInt()}% • 120 MB/s",
                                    color = PlayGreen,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { app.installProgress },
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                                color = PlayGreen,
                                trackColor = DarkCardBorder
                            )
                        }
                    } else if (app.isInstalled) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = onUninstall,
                                modifier = Modifier.weight(1f).height(42.dp),
                                shape = RoundedCornerShape(21.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444))
                            ) {
                                Text("Uninstall", fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = {
                                    val isNative = checkIfAppInstalled(context, app.id)
                                    if (isNative) {
                                        val launchIntent = context.packageManager.getLaunchIntentForPackage(app.id)
                                        if (launchIntent != null) {
                                            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                            context.startActivity(launchIntent)
                                            Toast.makeText(context, "Opening native ${app.title}...", Toast.LENGTH_SHORT).show()
                                            return@Button
                                        }
                                    }
                                    onLaunch()
                                },
                                modifier = Modifier.weight(1f).height(42.dp),
                                shape = RoundedCornerShape(21.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PlayGreen)
                            ) {
                                Icon(Icons.Default.PlayArrow, null, tint = Color.Black)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Play", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        Button(
                            onClick = {
                                onInstall()
                                launchRealAppOrPlayStore(context, app.id)
                            },
                            modifier = Modifier.fillMaxWidth().height(44.dp),
                            shape = RoundedCornerShape(22.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PlayGreen)
                        ) {
                            Icon(Icons.Default.Download, null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Install (${app.sizeMb} MB)",
                                color = Color.Black,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Direct Option: Download Real APK on Phone via official device Google Play Store
                    OutlinedButton(
                        onClick = {
                            launchRealAppOrPlayStore(context, app.id)
                        },
                        modifier = Modifier.fillMaxWidth().height(40.dp),
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = if (isNativeInstalled) CloudEmerald else PlayGreen
                        )
                    ) {
                        Icon(
                            if (isNativeInstalled) Icons.Default.RocketLaunch else Icons.Default.OpenInNew,
                            null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isNativeInstalled) "Open Native App on Device" else "Download Real APK on Phone (Google Play)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Screenshots Gallery
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Screenshots",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(4) { idx ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                                border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                                modifier = Modifier
                                    .width(200.dp)
                                    .height(115.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(
                                            Brush.linearGradient(
                                                listOf(
                                                    Color(app.accentHex).copy(alpha = 0.4f),
                                                    DarkSurface
                                                )
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        RealAppIcon(appId = app.id, title = app.title, size = 36.dp)
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "${app.title} 120 FPS Gameplay #${idx + 1}",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // About this app / game
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = if (app.isGame) "About this game" else "About this app",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = app.description,
                        color = Color(0xFFD1D5DB),
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Surface(
                            color = DarkSurfaceElevated,
                            shape = RoundedCornerShape(14.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
                        ) {
                            Text(
                                text = app.category,
                                color = Color.LightGray,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                        Surface(
                            color = DarkSurfaceElevated,
                            shape = RoundedCornerShape(14.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
                        ) {
                            Text(
                                text = "120 FPS Extreme",
                                color = CloudEmerald,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                        Surface(
                            color = DarkSurfaceElevated,
                            shape = RoundedCornerShape(14.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
                        ) {
                            Text(
                                text = "Play Protect Verified",
                                color = PlayGreen,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Ratings and reviews section
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Ratings and reviews",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.width(90.dp)
                        ) {
                            Text(
                                text = "${app.rating}",
                                color = Color.White,
                                fontSize = 36.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row {
                                repeat(5) {
                                    Icon(Icons.Default.Star, null, tint = Color(0xFFFBBF24), modifier = Modifier.size(12.dp))
                                }
                            }
                            Text(text = app.reviews, color = Color.Gray, fontSize = 10.sp)
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            RatingDistributionBar(stars = 5, progress = 0.85f)
                            RatingDistributionBar(stars = 4, progress = 0.10f)
                            RatingDistributionBar(stars = 3, progress = 0.03f)
                            RatingDistributionBar(stars = 2, progress = 0.01f)
                            RatingDistributionBar(stars = 1, progress = 0.01f)
                        }
                    }
                }
            }

            // Sample User Review
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(PlayGreen),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("A", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Alex R. (Verified Gamer)",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Text(text = "Yesterday", color = Color.Gray, fontSize = 10.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row {
                            repeat(5) {
                                Icon(Icons.Default.Star, null, tint = Color(0xFFFBBF24), modifier = Modifier.size(11.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Runs super smooth on this 10 Gbps cloud phone at 120 FPS! Instant loading, no lag at all and controls respond immediately.",
                            color = Color(0xFFD1D5DB),
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun RatingDistributionBar(stars: Int, progress: Float) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(text = "$stars", color = Color.Gray, fontSize = 10.sp, modifier = Modifier.width(12.dp))
        Spacer(modifier = Modifier.width(4.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
            color = PlayGreen,
            trackColor = DarkCardBorder
        )
    }
}

/**
 * Play Store Offers View
 */
@Composable
private fun PlayStoreOffersView(onExploreApp: (String) -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Offers & Play Pass",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Exclusive cloud gaming benefits included with your Cloud Phone session",
                color = Color.LightGray,
                fontSize = 12.sp
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, PlayGreen),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VerifiedUser, null, tint = PlayGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("10 Gbps Cloud Supercharger Pass", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "Download all games at up to 10,000 Mbps with zero local phone storage consumption and full hardware ray tracing.",
                        color = Color.LightGray,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { onExploreApp("com.roblox.client") },
                        colors = ButtonDefaults.buttonColors(containerColor = PlayGreen),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Claim Roblox VIP Perks", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/**
 * Play Store Books View
 */
@Composable
private fun PlayStoreBooksView() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.Book, null, tint = PlayGreen, modifier = Modifier.size(56.dp))
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "Google Play Books",
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Millions of ebooks, audiobooks, and comics available on Google Play.",
            color = Color.Gray,
            fontSize = 13.sp
        )
    }
}
