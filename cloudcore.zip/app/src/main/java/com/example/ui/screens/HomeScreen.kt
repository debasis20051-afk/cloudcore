package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.CloudDevice
import com.example.model.CloudWindow
import com.example.model.GoogleUserProfile
import com.example.model.PlayApp
import com.example.ui.components.GoogleSignInButton
import com.example.ui.components.RealAppIcon
import com.example.ui.components.RunWhenOffControlCard
import com.example.ui.theme.ChromeBlue
import com.example.ui.theme.CloudAmber
import com.example.ui.theme.CloudCyan
import com.example.ui.theme.CloudEmerald
import com.example.ui.theme.CloudViolet
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.PlayGreen

/**
 * High-End Cloud Phone Homepage
 * Features:
 * - Google Account Login / Profile Status
 * - Run When Phone Is Off 24/7 Cloud Engine
 * - One-Tap Launchers: Cloud Phone Desktop, Chrome, Google Play, 10G Speedtest, 120FPS Game
 * - Active Cloud Node Status & Telemetry
 * - Benefits of Cloud Gaming (0% Battery drain, 0% local storage used, 24/7 background farming)
 */
@Composable
fun HomeScreen(
    activeDevice: CloudDevice,
    googleUser: GoogleUserProfile,
    runWhenPhoneOff: Boolean,
    offlineHours: Int,
    offlineExp: Long,
    offlineGold: Long,
    onEnterCloudDevice: () -> Unit,
    onOpenChrome: () -> Unit,
    onOpenPlayStore: () -> Unit,
    onOpenSpeedtest: () -> Unit,
    onOpenSpecs: () -> Unit,
    onToggleRunWhenPhoneOff: () -> Unit,
    onSimulatePhoneOff: () -> Unit,
    onGoogleLoginClick: () -> Unit,
    onRebootCloudDevice: () -> Unit,
    isRebooting: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        // App Top Bar: Branding & Google Login Button
        Surface(
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // CloudCore Logo
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(listOf(CloudCyan, CloudViolet))
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Cloud,
                            contentDescription = "CloudCore",
                            tint = Color.Black,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "CloudCore VIP",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(CloudEmerald)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "24/7 Online Active",
                                color = CloudEmerald,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // Google Sign In Button
                GoogleSignInButton(
                    user = googleUser,
                    onClick = onGoogleLoginClick,
                    compact = true,
                    testTag = "home_google_signin_btn"
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(2.dp))
            }

            // Hero Banner: Cloud Android Virtual Machine
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CloudCyan.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        // Custom Wallpaper Graphic
                        Image(
                            painter = painterResource(id = R.drawable.img_custom_wallpaper_1790348100481),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(170.dp)
                        )

                        // Gradient Scrim
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(170.dp)
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            Color.Black.copy(alpha = 0.4f),
                                            Color.Black.copy(alpha = 0.85f)
                                        )
                                    )
                                )
                        )

                        // Content Overlay
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(CloudCyan.copy(alpha = 0.25f))
                                        .border(1.dp, CloudCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = "SNAPDRAGON 8 GEN 3 • 120 FPS",
                                        color = CloudCyan,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(CloudEmerald.copy(alpha = 0.25f))
                                        .border(1.dp, CloudEmerald.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = "10 Gbps FIBER",
                                        color = CloudEmerald,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = activeDevice.name,
                                color = Color.White,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = "Dedicated Cloud Phone Instance • Tokyo Data Center",
                                color = Color.LightGray,
                                fontSize = 12.sp
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Button(
                                onClick = onEnterCloudDevice,
                                colors = ButtonDefaults.buttonColors(containerColor = CloudCyan),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("home_enter_cloud_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PhoneAndroid,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Enter Cloud Phone Desktop",
                                    color = Color.Black,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = Icons.Default.ArrowForward,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Run When Phone Is Off 24/7 Feature Card
            item {
                RunWhenOffControlCard(
                    isEnabled = runWhenPhoneOff,
                    offlineHours = offlineHours,
                    farmedExp = offlineExp,
                    farmedGold = offlineGold,
                    onToggle = onToggleRunWhenPhoneOff,
                    onSimulatePhoneOff = onSimulatePhoneOff
                )
            }

            // Quick App Grid (Google Chrome, Google Play Store, 10G Speedtest, Genshin 120F)
            item {
                Text(
                    text = "Cloud Apps & Services",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    HomeAppLauncherCard(
                        title = "Chrome",
                        subtitle = "10G Browsing",
                        appId = "com.android.chrome",
                        icon = Icons.Default.Language,
                        color = ChromeBlue,
                        onClick = onOpenChrome,
                        modifier = Modifier.weight(1f),
                        testTag = "home_launch_chrome"
                    )
                    HomeAppLauncherCard(
                        title = "Play Store",
                        subtitle = "Apps & Games",
                        appId = "com.android.vending",
                        icon = Icons.Default.PlayArrow,
                        color = PlayGreen,
                        onClick = onOpenPlayStore,
                        modifier = Modifier.weight(1f),
                        testTag = "home_launch_playstore"
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    HomeAppLauncherCard(
                        title = "YouTube",
                        subtitle = "4K 120FPS Cloud",
                        appId = "com.google.android.youtube",
                        icon = Icons.Default.PlayArrow,
                        color = Color(0xFFEF4444),
                        onClick = onEnterCloudDevice,
                        modifier = Modifier.weight(1f),
                        testTag = "home_launch_youtube"
                    )
                    HomeAppLauncherCard(
                        title = "Device Specs",
                        subtitle = "Snapdragon 8 Gen 3",
                        appId = "specs",
                        icon = Icons.Default.Memory,
                        color = CloudViolet,
                        onClick = onOpenSpecs,
                        modifier = Modifier.weight(1f),
                        testTag = "home_launch_specs"
                    )
                }
            }

            // Why Cloud Phone? Architecture Highlight Cards
            item {
                Text(
                    text = "Cloud Phone Advantages",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = DarkSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        AdvantageBullet(
                            title = "Runs When Phone Is Off",
                            desc = "Your physical phone can be turned off, out of battery, or disconnected. The cloud phone keeps farming, downloading, and running 24/7.",
                            icon = Icons.Default.PowerSettingsNew,
                            tint = CloudEmerald
                        )
                        AdvantageBullet(
                            title = "Zero Battery & Storage Drain",
                            desc = "Apps run on server CPUs and RAM. 0MB consumed on your phone storage, and 0% battery heat generated.",
                            icon = Icons.Default.Bolt,
                            tint = CloudAmber
                        )
                        AdvantageBullet(
                            title = "Google Play & Chrome Integration",
                            desc = "Sideload APKs at 10 Gbps speeds, install apps directly from Google Play, and sync with your Google Account.",
                            icon = Icons.Default.Public,
                            tint = CloudCyan
                        )
                    }
                }
            }

            // Specs & Node Maintenance
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Node: Tokyo-Central #08",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "IP: ${activeDevice.ipAddress} • Ping: ${activeDevice.pingMs}ms",
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                            }

                            OutlinedButton(
                                onClick = onOpenSpecs,
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = CloudCyan),
                                modifier = Modifier.testTag("home_view_specs_btn")
                            ) {
                                Text("Specs", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun HomeAppLauncherCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    appId: String? = null,
    testTag: String = ""
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = DarkSurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.35f)),
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (appId != null) {
                RealAppIcon(
                    appId = appId,
                    title = title,
                    size = 42.dp
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(color.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = color,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    color = Color.LightGray,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun AdvantageBullet(
    title: String,
    desc: String,
    icon: ImageVector,
    tint: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(tint.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = tint,
                modifier = Modifier.size(16.dp)
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = desc,
                color = Color.Gray,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }
    }
}
