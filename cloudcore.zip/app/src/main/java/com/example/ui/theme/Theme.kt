package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CloudPhoneColorScheme = darkColorScheme(
    primary = CloudCyan,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF003847),
    onPrimaryContainer = Color(0xFF9CF4FF),
    secondary = CloudViolet,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF321A63),
    onSecondaryContainer = Color(0xFFE2D6FF),
    tertiary = CloudEmerald,
    onTertiary = Color.Black,
    tertiaryContainer = Color(0xFF003824),
    onTertiaryContainer = Color(0xFF75F8BE),
    background = DarkBg,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = DarkCardBorder,
    outlineVariant = DarkSurfaceHighlight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use our signature cyber cloud aesthetic
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = CloudPhoneColorScheme,
        typography = Typography,
        content = content
    )
}
