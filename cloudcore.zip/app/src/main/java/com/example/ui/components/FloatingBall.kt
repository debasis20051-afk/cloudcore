package com.example.ui.components

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.PlayApp
import com.example.ui.theme.CloudCyan
import com.example.ui.theme.CloudEmerald
import com.example.ui.theme.CloudViolet
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.util.AppMetadataResolver
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

data class UploadedFileInfo(
    val name: String,
    val sizeBytes: Long,
    val isApk: Boolean
)

/**
 * Draggable Floating Ball with glowing Cybernetic Cloud Orb design.
 * Replaces the static right slide bar per user instructions.
 * Tapping opens the Cloud Control Center with:
 * - 3 Bars Virtual Recents button
 * - Virtual Back button
 * - Home button
 * - Exit button
 * - Upload File option (with APK install & Cloud storage)
 * - Gamepad, AFK, 10G Net, Config, Fleet controls
 */
@Composable
fun CloudFloatingBall(
    pingMs: Int,
    fps: Int,
    isAfkActive: Boolean,
    isKeymappingActive: Boolean,
    runningApps: List<PlayApp>,
    onHomeClick: () -> Unit,
    onBackClick: () -> Unit,
    onExitClick: () -> Unit,
    onToggleKeymapping: () -> Unit,
    onToggleAfk: () -> Unit,
    onSpeedtestClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onFleetClick: () -> Unit,
    onInstallUploadedApk: (title: String, packageName: String, developer: String, category: String, sizeMb: Int, isGame: Boolean, accentHex: Long) -> Unit,
    onLaunchApp: (PlayApp) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Floating Ball drag coordinates (defaults to right edge, middle)
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    // Dialog & overlay states
    var isMenuOpen by remember { mutableStateOf(false) }
    var isRecentsOpen by remember { mutableStateOf(false) }
    var isUploadDialogOpen by remember { mutableStateOf(false) }

    // Upload state
    var selectedFile by remember { mutableStateOf<UploadedFileInfo?>(null) }
    var isUploading by remember { mutableStateOf(false) }
    var uploadProgress by remember { mutableFloatStateOf(0f) }
    var uploadSuccess by remember { mutableStateOf(false) }

    // System File Picker for the "Upload File" feature
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            var fileName = "cloud_upload_file"
            var fileSize = 15_000_000L // fallback 15 MB
            try {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (cursor.moveToFirst()) {
                        if (nameIdx >= 0) fileName = cursor.getString(nameIdx) ?: fileName
                        if (sizeIdx >= 0) fileSize = cursor.getLong(sizeIdx).coerceAtLeast(1024L)
                    }
                }
            } catch (_: Exception) {}

            val isApk = fileName.endsWith(".apk", ignoreCase = true)
            selectedFile = UploadedFileInfo(name = fileName, sizeBytes = fileSize, isApk = isApk)
            isUploadDialogOpen = true
            isUploading = true
            uploadProgress = 0f
            uploadSuccess = false

            // Simulate high-speed 10 Gbps cloud pipeline upload
            scope.launch {
                val totalSteps = 10
                for (step in 1..totalSteps) {
                    delay(80)
                    uploadProgress = step / 10f
                }
                isUploading = false
                uploadSuccess = true
            }
        }
    }

    // Glowing animation for the floating ball
    val infiniteTransition = rememberInfiniteTransition(label = "orbPulse")
    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(10000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orbRotate"
    )

    Box(modifier = modifier) {
        // --- 1. THE FLOATING BALL (DRAGGABLE) ---
        Box(
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        offsetX += dragAmount.x
                        offsetY += dragAmount.y
                    }
                }
                .size(52.dp)
                .shadow(12.dp, CircleShape)
                .clip(CircleShape)
                .clickable { isMenuOpen = !isMenuOpen }
                .testTag("floating_cloud_ball"),
            contentAlignment = Alignment.Center
        ) {
            // High-Tech Cybernetic Orb Canvas
            Canvas(modifier = Modifier.fillMaxSize()) {
                val r = size.minDimension / 2f
                val c = center

                // Outer pulsing ring
                drawCircle(
                    color = CloudCyan.copy(alpha = 0.35f * pulseGlow),
                    radius = r - 1.dp.toPx(),
                    style = Stroke(width = 2.5.dp.toPx())
                )

                // High-tech rotating tick marks
                val ringRadius = r - 5.dp.toPx()
                drawCircle(
                    brush = Brush.sweepGradient(
                        listOf(CloudCyan, CloudViolet, CloudEmerald, CloudCyan)
                    ),
                    radius = ringRadius,
                    style = Stroke(width = 2.dp.toPx())
                )

                // Glowing orb core gradient
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF0EA5E9),
                            Color(0xFF1E1B4B),
                            Color(0xFF030712)
                        ),
                        center = c,
                        radius = r - 6.dp.toPx()
                    ),
                    radius = r - 6.dp.toPx()
                )
            }

            // Central Cloud / Gaming Insignia
            Icon(
                imageVector = Icons.Default.Cloud,
                contentDescription = "Cloud Ball",
                tint = Color.White,
                modifier = Modifier
                    .size(24.dp)
                    .rotate(rotationAngle * 0.1f)
            )

            // Mini ping badge at top right
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = (-2).dp, y = 2.dp)
                    .clip(CircleShape)
                    .background(if (pingMs < 10) CloudEmerald else Color(0xFFFBBF24))
                    .size(8.dp)
            )
        }

        // --- 2. EXPANDED FLOATING BALL CONTROL CENTER (POPUP OVERLAY) ---
        AnimatedVisibility(
            visible = isMenuOpen,
            enter = fadeIn() + scaleIn(initialScale = 0.85f),
            exit = fadeOut() + scaleOut(targetScale = 0.85f)
        ) {
            Dialog(onDismissRequest = { isMenuOpen = false }) {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.98f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CloudCyan.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                        .shadow(20.dp, RoundedCornerShape(24.dp))
                        .testTag("floating_ball_menu_card")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Header with Live Telemetry & Close
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(CloudEmerald)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "Cloud Control Ball",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${pingMs}ms latency • ${fps} FPS • 10 Gbps",
                                        color = CloudEmerald,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            IconButton(
                                onClick = { isMenuOpen = false },
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(DarkSurfaceElevated)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.LightGray, modifier = Modifier.size(18.dp))
                            }
                        }

                        // --- SECTION A: VIRTUAL NAVIGATION CONTROLS ---
                        // (Virtual Back, 3 Bars Recents, Home, Exit button)
                        Text(
                            text = "VIRTUAL NAVIGATION",
                            color = CloudCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // 1. Virtual Back Button
                            NavControlButton(
                                icon = Icons.Default.ArrowBack,
                                title = "Back",
                                subtitle = "Return",
                                color = Color(0xFF38BDF8),
                                onClick = {
                                    isMenuOpen = false
                                    onBackClick()
                                },
                                modifier = Modifier.weight(1f),
                                testTag = "nav_back_btn"
                            )

                            // 2. Virtual 3 Bars Button (Android Recents / Overview Task Switcher)
                            NavControlButton(
                                icon = Icons.Default.Menu,
                                title = "3 Bars (|||)",
                                subtitle = "Recents",
                                color = Color(0xFFA855F7),
                                onClick = {
                                    isMenuOpen = false
                                    isRecentsOpen = true
                                },
                                modifier = Modifier.weight(1f),
                                testTag = "nav_recents_3bars_btn"
                            )

                            // 3. Home Button
                            NavControlButton(
                                icon = Icons.Default.Home,
                                title = "Home",
                                subtitle = "Desktop",
                                color = Color(0xFF10B981),
                                onClick = {
                                    isMenuOpen = false
                                    onHomeClick()
                                },
                                modifier = Modifier.weight(1f),
                                testTag = "nav_home_btn"
                            )

                            // 4. Exit Button
                            NavControlButton(
                                icon = Icons.Default.PowerSettingsNew,
                                title = "Exit",
                                subtitle = "Close App",
                                color = Color(0xFFEF4444),
                                onClick = {
                                    isMenuOpen = false
                                    onExitClick()
                                },
                                modifier = Modifier.weight(1f),
                                testTag = "nav_exit_btn"
                            )
                        }

                        // --- SECTION B: UPLOAD FILE FEATURE ---
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = DarkSurfaceElevated,
                            border = androidx.compose.foundation.BorderStroke(1.dp, CloudCyan.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        isMenuOpen = false
                                        filePickerLauncher.launch("*/*")
                                    }
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(
                                                Brush.linearGradient(
                                                    listOf(Color(0xFF0284C7), Color(0xFF0369A1))
                                                )
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.UploadFile,
                                            contentDescription = "Upload",
                                            tint = Color.White,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = "Upload Any File to Cloud",
                                            color = Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Sideload APKs, OBBs, ROMs, or data (10 Gbps)",
                                            color = Color.Gray,
                                            fontSize = 10.sp
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        isMenuOpen = false
                                        filePickerLauncher.launch("*/*")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = CloudCyan),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Text("Pick File", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // --- SECTION C: CLOUD GAMING & TOOLBOX ---
                        Text(
                            text = "CLOUD GAMING TOOLBOX",
                            color = CloudCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Gamepad
                            QuickActionButton(
                                icon = Icons.Default.Gamepad,
                                label = "Gamepad",
                                isActive = isKeymappingActive,
                                activeColor = CloudCyan,
                                onClick = {
                                    onToggleKeymapping()
                                    isMenuOpen = false
                                },
                                modifier = Modifier.weight(1f)
                            )

                            // AFK Macro
                            QuickActionButton(
                                icon = if (isAfkActive) Icons.Default.Stop else Icons.Default.PlayArrow,
                                label = "AFK Farm",
                                isActive = isAfkActive,
                                activeColor = CloudEmerald,
                                onClick = {
                                    onToggleAfk()
                                    isMenuOpen = false
                                },
                                modifier = Modifier.weight(1f)
                            )

                            // 10G Net
                            QuickActionButton(
                                icon = Icons.Default.Speed,
                                label = "10G Net",
                                isActive = false,
                                activeColor = CloudCyan,
                                onClick = {
                                    isMenuOpen = false
                                    onSpeedtestClick()
                                },
                                modifier = Modifier.weight(1f)
                            )

                            // Config
                            QuickActionButton(
                                icon = Icons.Default.Tune,
                                label = "Config",
                                isActive = false,
                                activeColor = Color.White,
                                onClick = {
                                    isMenuOpen = false
                                    onSettingsClick()
                                },
                                modifier = Modifier.weight(1f)
                            )

                            // Fleet
                            QuickActionButton(
                                icon = Icons.Default.Dashboard,
                                label = "Fleet",
                                isActive = false,
                                activeColor = CloudViolet,
                                onClick = {
                                    isMenuOpen = false
                                    onFleetClick()
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // --- 3. VIRTUAL 3-BARS RECENTS TASK SWITCHER SHEET ---
        if (isRecentsOpen) {
            Dialog(onDismissRequest = { isRecentsOpen = false }) {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CloudViolet.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Menu, contentDescription = null, tint = CloudViolet)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Virtual Overview (3 Bars)",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            IconButton(onClick = { isRecentsOpen = false }) {
                                Icon(Icons.Default.Close, null, tint = Color.Gray)
                            }
                        }

                        Text(
                            text = "Active Cloud Instances & Background Apps",
                            color = Color.Gray,
                            fontSize = 11.sp
                        )

                        // List open running apps or default active tasks
                        val displayTasks = if (runningApps.isNotEmpty()) runningApps else listOf(
                            PlayApp(
                                id = "com.roblox.client",
                                title = "Roblox",
                                developer = "Roblox Corporation",
                                category = "Games",
                                rating = 4.8f,
                                reviews = "10M+",
                                downloads = "1B+",
                                sizeMb = 160,
                                isInstalled = true,
                                description = "Running in cloud 24/7",
                                isGame = true
                            ),
                            PlayApp(
                                id = "com.android.chrome",
                                title = "Google Chrome",
                                developer = "Google LLC",
                                category = "Browser",
                                rating = 4.5f,
                                reviews = "100M+",
                                downloads = "10B+",
                                sizeMb = 98,
                                isInstalled = true,
                                description = "Active tabs synced",
                                isGame = false
                            )
                        )

                        displayTasks.forEach { task ->
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = DarkSurfaceElevated,
                                border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        isRecentsOpen = false
                                        onLaunchApp(task)
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RealAppIcon(appId = task.id, title = task.title, size = 38.dp)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(task.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text("RAM: 1.2 GB • 120 FPS Background", color = CloudEmerald, fontSize = 10.sp)
                                    }
                                    Button(
                                        onClick = {
                                            isRecentsOpen = false
                                            onLaunchApp(task)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = CloudViolet),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.height(30.dp)
                                    ) {
                                        Text("Switch", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Button(
                                onClick = {
                                    isRecentsOpen = false
                                    onHomeClick()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.DeleteSweep, null, tint = Color.LightGray, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Clear Background Cache", color = Color.White, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // --- 4. UPLOAD PROGRESS & APK SIDELOAD INSTALLER DIALOG ---
        if (isUploadDialogOpen && selectedFile != null) {
            val file = selectedFile!!
            Dialog(onDismissRequest = { isUploadDialogOpen = false }) {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CloudCyan.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape)
                                .background(if (uploadSuccess) CloudEmerald.copy(alpha = 0.2f) else CloudCyan.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (uploadSuccess) Icons.Default.CheckCircle else Icons.Default.CloudUpload,
                                contentDescription = null,
                                tint = if (uploadSuccess) CloudEmerald else CloudCyan,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        Text(
                            text = if (uploadSuccess) "Upload Complete!" else "Uploading to 10G Cloud Phone...",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )

                        // File details card
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = DarkSurfaceElevated,
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (file.isApk) Icons.Default.FileDownload else Icons.Default.InsertDriveFile,
                                    contentDescription = null,
                                    tint = if (file.isApk) CloudEmerald else CloudCyan,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = file.name,
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${String.format("%.1f", file.sizeBytes / (1024f * 1024f))} MB • /sdcard/Download/",
                                        color = Color.Gray,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }

                        if (isUploading) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                LinearProgressIndicator(
                                    progress = { uploadProgress },
                                    modifier = Modifier.fillMaxWidth().height(6.dp),
                                    color = CloudCyan,
                                    trackColor = DarkSurfaceElevated
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Speed: 10,000 Mbps Fiber", color = CloudEmerald, fontSize = 10.sp)
                                    Text("${(uploadProgress * 100).toInt()}%", color = Color.White, fontSize = 10.sp)
                                }
                            }
                        }

                        if (uploadSuccess) {
                            if (file.isApk) {
                                // Direct 1-tap APK Sideload Installation into Cloud Phone!
                                val rawName = file.name.substringBeforeLast(".apk")
                                val resolved = AppMetadataResolver.resolve(rawName, rawName)

                                Button(
                                    onClick = {
                                        onInstallUploadedApk(
                                            resolved.title,
                                            "com.custom.${rawName.lowercase().replace(" ", "_")}",
                                            resolved.developer,
                                            resolved.category,
                                            (file.sizeBytes / (1024 * 1024)).toInt().coerceAtLeast(20),
                                            resolved.isGame,
                                            resolved.accentHex
                                        )
                                        isUploadDialogOpen = false
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = CloudEmerald),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.FileDownload, null, tint = Color.Black)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Install '${resolved.title}' on Desktop", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            } else {
                                Button(
                                    onClick = { isUploadDialogOpen = false },
                                    colors = ButtonDefaults.buttonColors(containerColor = CloudCyan),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Done", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NavControlButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = color.copy(alpha = 0.12f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.35f)),
        modifier = modifier
            .testTag(testTag)
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = color,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                text = subtitle,
                color = color,
                fontSize = 9.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun QuickActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isActive: Boolean,
    activeColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isActive) activeColor.copy(alpha = 0.2f) else DarkSurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isActive) activeColor else DarkCardBorder),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isActive) activeColor else Color.LightGray,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                color = if (isActive) activeColor else Color.LightGray,
                fontSize = 9.sp,
                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                textAlign = TextAlign.Center
            )
        }
    }
}
