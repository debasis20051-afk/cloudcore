package com.example.ui.screens

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.InstallMobile
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import com.example.model.PlayApp
import com.example.ui.theme.ChromeBlue
import com.example.ui.theme.ChromeGreen
import com.example.ui.theme.ChromeRed
import com.example.ui.theme.ChromeYellow
import com.example.ui.theme.CloudCyan
import com.example.ui.theme.CloudEmerald
import com.example.ui.theme.CloudViolet
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.PlayGreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class QuickBookmark(
    val title: String,
    val url: String,
    val iconColor: Color,
    val initial: String
)

data class SideloadCandidate(
    val title: String,
    val packageName: String,
    val developer: String,
    val category: String,
    val sizeMb: Int,
    val isGame: Boolean,
    val accentHex: Long,
    val versionName: String,
    val downloadUrl: String,
    val description: String
)

enum class InstallDialogState {
    IDLE,
    DOWNLOADING_10G,
    PLAY_PROTECT_SCAN,
    PACKAGE_INSTALLER_PROMPT,
    INSTALLING_SYSTEM,
    INSTALLED_SUCCESS
}

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ChromeScreen(
    currentUrl: String,
    onNavigateUrl: (String) -> Unit,
    onCloseBrowser: () -> Unit,
    tabsCount: Int,
    onNewTab: () -> Unit,
    onInstallCustomApk: (title: String, packageName: String, developer: String, category: String, sizeMb: Int, isGame: Boolean, accentHex: Long) -> Unit = { _, _, _, _, _, _, _ -> },
    onLaunchApp: (PlayApp) -> Unit = {},
    installedApps: List<PlayApp> = emptyList(),
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var inputUrl by remember(currentUrl) { mutableStateOf(currentUrl) }
    var pageTitle by remember { mutableStateOf("Google Chrome") }
    var isLoading by remember { mutableStateOf(false) }
    var progressVal by remember { mutableIntStateOf(0) }
    var showMenu by remember { mutableStateOf(false) }
    var isDesktopMode by remember { mutableStateOf(false) }
    var isNewTabHome by remember { mutableStateOf(currentUrl.isEmpty() || currentUrl == "chrome://newtab") }

    // Sideload and APK Hub states
    var showSideloadSheet by remember { mutableStateOf(false) }
    var showCustomUrlDialog by remember { mutableStateOf(false) }
    var customApkUrlInput by remember { mutableStateOf("") }
    var customApkNameInput by remember { mutableStateOf("") }

    // Active package install session
    var activeCandidate by remember { mutableStateOf<SideloadCandidate?>(null) }
    var installDialogState by remember { mutableStateOf(InstallDialogState.IDLE) }
    var downloadProgress by remember { mutableFloatStateOf(0f) }
    var downloadSpeedText by remember { mutableStateOf("9,840 Mbps (10G Optical)") }

    // Popular Real Apps ready to Sideload
    val realAppsCatalog = remember {
        listOf(
            SideloadCandidate(
                title = "NewPipe",
                packageName = "org.schabi.newpipe",
                developer = "Team NewPipe",
                category = "Media & Video",
                sizeMb = 14,
                isGame = false,
                accentHex = 0xFFDC2626,
                versionName = "0.27.0",
                downloadUrl = "https://github.com/TeamNewPipe/NewPipe/releases/download/v0.27.0/NewPipe_v0.27.0.apk",
                description = "Lightweight streaming frontend for YouTube with zero ads and 4K 60FPS support."
            ),
            SideloadCandidate(
                title = "CPU-Z",
                packageName = "com.cpuid.cpu_z",
                developer = "CPUID",
                category = "Tools",
                sizeMb = 4,
                isGame = false,
                accentHex = 0xFF10B981,
                versionName = "1.43",
                downloadUrl = "https://cpuid.com/downloads/cpu-z/cpu-z_1.43.apk",
                description = "System hardware monitor reporting real-time Snapdragon 8 Gen 3 core clocks & temps."
            ),
            SideloadCandidate(
                title = "Discord",
                packageName = "com.discord",
                developer = "Discord Inc.",
                category = "Communication",
                sizeMb = 89,
                isGame = false,
                accentHex = 0xFF5865F2,
                versionName = "215.12",
                downloadUrl = "https://discord.com/api/download/android",
                description = "Voice, video, and text communication service for gaming communities."
            ),
            SideloadCandidate(
                title = "Spotify Lite",
                packageName = "com.spotify.lite",
                developer = "Spotify AB",
                category = "Music & Audio",
                sizeMb = 18,
                isGame = false,
                accentHex = 0xFF22C55E,
                versionName = "1.9.0",
                downloadUrl = "https://spotify.com/download/android-lite.apk",
                description = "Millions of songs and podcasts optimized for ultra-fast cloud performance."
            ),
            SideloadCandidate(
                title = "WhatsApp Messenger",
                packageName = "com.whatsapp",
                developer = "WhatsApp LLC",
                category = "Communication",
                sizeMb = 48,
                isGame = false,
                accentHex = 0xFF25D366,
                versionName = "2.24.11",
                downloadUrl = "https://whatsapp.com/android/WhatsApp.apk",
                description = "Simple, reliable private messaging and calls worldwide."
            )
        )
    }

    // Function to trigger 10G Download and Package Installer flow
    val startInstallFlow: (SideloadCandidate) -> Unit = { candidate ->
        activeCandidate = candidate
        installDialogState = InstallDialogState.DOWNLOADING_10G
        downloadProgress = 0.05f

        coroutineScope.launch {
            // Step 1: 10 Gbps Ultra-fast Download simulation
            val totalSteps = 8
            for (step in 1..totalSteps) {
                delay(120) // ~1 second total for full APK download over 10G fiber!
                downloadProgress = step.toFloat() / totalSteps
            }

            // Step 2: Google Play Protect Scan
            installDialogState = InstallDialogState.PLAY_PROTECT_SCAN
            delay(500)

            // Step 3: Android Package Installer Prompt
            installDialogState = InstallDialogState.PACKAGE_INSTALLER_PROMPT
        }
    }

    val executeInstallToCloud: () -> Unit = {
        val cand = activeCandidate
        if (cand != null) {
            installDialogState = InstallDialogState.INSTALLING_SYSTEM
            coroutineScope.launch {
                delay(700)
                // Install into Room Database & memory
                onInstallCustomApk(
                    cand.title,
                    cand.packageName,
                    cand.developer,
                    cand.category,
                    cand.sizeMb,
                    cand.isGame,
                    cand.accentHex
                )
                installDialogState = InstallDialogState.INSTALLED_SUCCESS
            }
        }
    }

    val installToPhysicalHostDevice: () -> Unit = {
        try {
            // Intent to trigger official Android Package Installer on physical device
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(
                    Uri.parse("content://dummy/download/${activeCandidate?.packageName}.apk"),
                    "application/vnd.android.package-archive"
                )
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(
                context,
                "Package installer dispatched. Installing ${activeCandidate?.title} to host system.",
                Toast.LENGTH_SHORT
            ).show()
        }
        executeInstallToCloud()
    }

    val quickBookmarks = remember {
        listOf(
            QuickBookmark("Google", "https://www.google.com", ChromeBlue, "G"),
            QuickBookmark("YouTube", "https://m.youtube.com", ChromeRed, "YT"),
            QuickBookmark("APKPure", "https://m.apkpure.com", CloudEmerald, "APK"),
            QuickBookmark("APKMirror", "https://www.apkmirror.com", Color(0xFFF59E0B), "MIR"),
            QuickBookmark("GitHub", "https://github.com", Color(0xFF1F2937), "GH"),
            QuickBookmark("F-Droid", "https://f-droid.org", Color(0xFF3B82F6), "FD")
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        // Top Chrome Omnibox Toolbar
        Surface(
            color = DarkSurface,
            tonalElevation = 4.dp,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Home shortcut
                    IconButton(
                        onClick = {
                            isNewTabHome = true
                            inputUrl = "https://www.google.com"
                            onNavigateUrl("https://www.google.com")
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("chrome_home_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Home,
                            contentDescription = "Chrome Home",
                            tint = Color.LightGray,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Omnibox (Address & Search Bar)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .clip(RoundedCornerShape(21.dp))
                            .background(DarkSurfaceElevated)
                            .padding(horizontal = 12.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "SSL Secure",
                                tint = CloudEmerald,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))

                            OutlinedTextField(
                                value = inputUrl,
                                onValueChange = { inputUrl = it },
                                singleLine = true,
                                textStyle = MaterialTheme.typography.bodyMedium.copy(
                                    color = Color.White,
                                    fontSize = 13.sp
                                ),
                                placeholder = {
                                    Text(
                                        "Search or type URL (e.g. apkpure.com)",
                                        color = Color.Gray,
                                        fontSize = 12.sp,
                                        maxLines = 1
                                    )
                                },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Uri,
                                    imeAction = ImeAction.Go
                                ),
                                keyboardActions = KeyboardActions(
                                    onGo = {
                                        isNewTabHome = false
                                        onNavigateUrl(inputUrl)
                                    }
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color.Transparent,
                                    unfocusedBorderColor = Color.Transparent,
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("chrome_omnibox_input")
                            )

                            if (isLoading) {
                                IconButton(
                                    onClick = { webViewInstance?.stopLoading() },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Stop",
                                        tint = Color.LightGray,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            } else {
                                IconButton(
                                    onClick = {
                                        isNewTabHome = false
                                        webViewInstance?.reload()
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "Reload",
                                        tint = Color.LightGray,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Dedicated APK Sideload & Package Installer Button in Omnibox
                    IconButton(
                        onClick = { showSideloadSheet = true },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(CloudCyan.copy(alpha = 0.15f))
                            .testTag("chrome_sideload_apk_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.InstallMobile,
                            contentDescription = "Install Real APKs",
                            tint = CloudCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Tab Count Box
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(DarkSurfaceElevated)
                            .clickable { onNewTab() },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$tabsCount",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // 3-dot Menu
                    Box {
                        IconButton(
                            onClick = { showMenu = true },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "Chrome Menu",
                                tint = Color.LightGray,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                            modifier = Modifier.background(DarkSurfaceElevated)
                        ) {
                            DropdownMenuItem(
                                text = { Text("Install APK from Web", color = CloudCyan, fontWeight = FontWeight.Bold) },
                                leadingIcon = { Icon(Icons.Default.InstallMobile, null, tint = CloudCyan) },
                                onClick = {
                                    showMenu = false
                                    showSideloadSheet = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Install custom APK URL", color = Color.White) },
                                leadingIcon = { Icon(Icons.Default.Link, null, tint = Color.White) },
                                onClick = {
                                    showMenu = false
                                    showCustomUrlDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("New tab", color = Color.White) },
                                leadingIcon = { Icon(Icons.Default.Add, null, tint = Color.White) },
                                onClick = {
                                    showMenu = false
                                    isNewTabHome = true
                                    onNewTab()
                                }
                            )
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        if (isDesktopMode) "Mobile site" else "Desktop site",
                                        color = Color.White
                                    )
                                },
                                leadingIcon = { Icon(Icons.Default.Computer, null, tint = CloudCyan) },
                                onClick = {
                                    showMenu = false
                                    isDesktopMode = !isDesktopMode
                                    webViewInstance?.settings?.apply {
                                        userAgentString = if (isDesktopMode) {
                                            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
                                        } else {
                                            null
                                        }
                                    }
                                    webViewInstance?.reload()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Close Chrome", color = Color.Red) },
                                leadingIcon = { Icon(Icons.Default.Clear, null, tint = Color.Red) },
                                onClick = {
                                    showMenu = false
                                    onCloseBrowser()
                                }
                            )
                        }
                    }
                }

                // Loading progress bar
                if (isLoading) {
                    LinearProgressIndicator(
                        progress = { progressVal / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.dp),
                        color = CloudCyan,
                        trackColor = Color.Transparent
                    )
                }
            }
        }

        // Web Content or Chrome New Tab
        Box(modifier = Modifier.weight(1f)) {
            // Functional WebView with APK download interception
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            loadWithOverviewMode = true
                            useWideViewPort = true
                            databaseEnabled = true
                            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                            cacheMode = WebSettings.LOAD_DEFAULT
                        }

                        // Intercept direct file downloads (e.g. from APKPure / APKMirror / GitHub)
                        setDownloadListener { url, _, contentDisposition, mimetype, _ ->
                            val detectedName = url.substringAfterLast("/").substringBefore("?").ifEmpty { "downloaded-app.apk" }
                            val cleanTitle = detectedName.replace(".apk", "").replace("-", " ").capitalize()
                            startInstallFlow(
                                SideloadCandidate(
                                    title = cleanTitle,
                                    packageName = "com.sideload.${cleanTitle.lowercase().replace(" ", "")}",
                                    developer = "Web Sideload",
                                    category = "Downloaded App",
                                    sizeMb = 45,
                                    isGame = false,
                                    accentHex = 0xFF00E5FF,
                                    versionName = "1.0.0",
                                    downloadUrl = url,
                                    description = "Downloaded via Chrome 10 Gbps direct pipe from $url"
                                )
                            )
                        }

                        webViewClient = object : WebViewClient() {
                            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                super.onPageStarted(view, url, favicon)
                                isLoading = true
                                url?.let { inputUrl = it }
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                super.onPageFinished(view, url)
                                isLoading = false
                                url?.let {
                                    inputUrl = it
                                    pageTitle = view?.title ?: "Google Chrome"
                                }
                            }

                            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                val url = request?.url?.toString() ?: return false
                                if (url.endsWith(".apk", ignoreCase = true) || url.contains(".apk?")) {
                                    val name = url.substringAfterLast("/").substringBefore("?").replace(".apk", "")
                                    startInstallFlow(
                                        SideloadCandidate(
                                            title = name.replace("-", " ").capitalize(),
                                            packageName = "com.sideload.${name.lowercase().replace("-", "")}",
                                            developer = "Web Sideload",
                                            category = "Tools",
                                            sizeMb = 50,
                                            isGame = false,
                                            accentHex = 0xFF00E5FF,
                                            versionName = "1.0",
                                            downloadUrl = url,
                                            description = "Downloaded from $url"
                                        )
                                    )
                                    return true
                                }
                                return false
                            }
                        }

                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                progressVal = newProgress
                                if (newProgress == 100) isLoading = false
                            }

                            override fun onReceivedTitle(view: WebView?, title: String?) {
                                title?.let { pageTitle = it }
                            }
                        }

                        loadUrl(currentUrl)
                        webViewInstance = this
                    }
                },
                update = { webView ->
                    if (webView.url != currentUrl && currentUrl.isNotEmpty()) {
                        webView.loadUrl(currentUrl)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )

            // Chrome Quick-Dial overlay if New Tab
            if (isNewTabHome) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(DarkBg)
                        .padding(horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    item {
                        Spacer(modifier = Modifier.height(24.dp))

                        // Chrome 4-color Logo Badge
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.sweepGradient(
                                            listOf(ChromeRed, ChromeYellow, ChromeGreen, ChromeBlue, ChromeRed)
                                        )
                                    )
                            )
                            Text(
                                text = "Google Chrome",
                                color = Color.White,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "10 Gbps Cloud Browser & APK Package Installer",
                            color = CloudCyan,
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        // Search Pill
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(24.dp))
                                .background(DarkSurfaceElevated)
                                .clickable {
                                    isNewTabHome = false
                                    onNavigateUrl("https://www.google.com")
                                }
                                .padding(horizontal = 16.dp, vertical = 12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Search, null, tint = Color.Gray, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Search Google or type a URL", color = Color.Gray, fontSize = 13.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Bookmarks Grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            quickBookmarks.forEach { bm ->
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable {
                                            isNewTabHome = false
                                            inputUrl = bm.url
                                            onNavigateUrl(bm.url)
                                        }
                                        .padding(4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(CircleShape)
                                            .background(bm.iconColor.copy(alpha = 0.25f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = bm.initial,
                                            color = bm.iconColor,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = bm.title,
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        // Sideload & Real Apps Installation Section
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = DarkSurfaceElevated,
                            border = androidx.compose.foundation.BorderStroke(1.dp, CloudCyan.copy(alpha = 0.35f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.InstallMobile,
                                            contentDescription = null,
                                            tint = CloudCyan,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "⚡ Sideload & Install Real Apps",
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(CloudEmerald.copy(alpha = 0.2f))
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text("10G Fiber", color = CloudEmerald, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                Text(
                                    text = "Install any APK from the web directly into your CloudCore virtual phone or host device with Play Protect security verification.",
                                    color = Color.LightGray,
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = { showSideloadSheet = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = CloudCyan),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Download, null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Top APKs", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }

                                    OutlinedButton(
                                        onClick = { showCustomUrlDialog = true },
                                        border = androidx.compose.foundation.BorderStroke(1.dp, CloudCyan),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Link, null, tint = CloudCyan, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Paste URL", color = CloudCyan, fontSize = 12.sp)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Quick-Install Grid of Real Apps
                        Text(
                            text = "Featured Real Apps (One-Tap 10G Install)",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            textAlign = TextAlign.Start
                        )
                    }

                    items(realAppsCatalog.take(4)) { candidate ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DarkSurface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(Color(candidate.accentHex)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = candidate.title.take(2).uppercase(),
                                            color = Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = candidate.title,
                                            color = Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${candidate.packageName} • ${candidate.sizeMb}MB",
                                            color = Color.Gray,
                                            fontSize = 10.sp
                                        )
                                    }
                                }

                                val isAlreadyInstalled = installedApps.any { it.id == candidate.packageName }

                                if (isAlreadyInstalled) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(16.dp))
                                            .background(DarkSurfaceElevated)
                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Text("Installed", color = CloudEmerald, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                } else {
                                    Button(
                                        onClick = { startInstallFlow(candidate) },
                                        colors = ButtonDefaults.buttonColors(containerColor = CloudCyan),
                                        shape = RoundedCornerShape(16.dp),
                                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                                    ) {
                                        Text("Install", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            }
        }
    }

    // Modal BottomSheet for Sideload & Real Apps catalog
    if (showSideloadSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSideloadSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = DarkSurfaceElevated
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Cloud Package Sideload Center",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Install genuine Android APKs with 10 Gbps optical pipe",
                            color = CloudCyan,
                            fontSize = 12.sp
                        )
                    }
                    IconButton(onClick = { showSideloadSheet = false }) {
                        Icon(Icons.Default.Clear, "Close", tint = Color.Gray)
                    }
                }

                // Sideload Web Portals Shortcut Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            showSideloadSheet = false
                            isNewTabHome = false
                            inputUrl = "https://m.apkpure.com"
                            onNavigateUrl("https://m.apkpure.com")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurface),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("APKPure", color = CloudEmerald, fontSize = 11.sp)
                    }
                    Button(
                        onClick = {
                            showSideloadSheet = false
                            isNewTabHome = false
                            inputUrl = "https://www.apkmirror.com"
                            onNavigateUrl("https://www.apkmirror.com")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurface),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("APKMirror", color = Color(0xFFF59E0B), fontSize = 11.sp)
                    }
                    Button(
                        onClick = {
                            showSideloadSheet = false
                            isNewTabHome = false
                            inputUrl = "https://f-droid.org"
                            onNavigateUrl("https://f-droid.org")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurface),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("F-Droid", color = CloudCyan, fontSize = 11.sp)
                    }
                }

                Text(
                    text = "Select an APK to install:",
                    color = Color.LightGray,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(realAppsCatalog) { candidate ->
                        val isInstalled = installedApps.any { it.id == candidate.packageName }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = DarkSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(candidate.accentHex)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = candidate.title.take(2).uppercase(),
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(candidate.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text("${candidate.category} • v${candidate.versionName} • ${candidate.sizeMb}MB", color = Color.Gray, fontSize = 10.sp)
                                    }
                                }

                                if (isInstalled) {
                                    Text("Installed", color = CloudEmerald, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                } else {
                                    Button(
                                        onClick = {
                                            showSideloadSheet = false
                                            startInstallFlow(candidate)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = CloudCyan),
                                        shape = RoundedCornerShape(14.dp)
                                    ) {
                                        Text("Install", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }

    // Custom APK URL Input Dialog
    if (showCustomUrlDialog) {
        Dialog(onDismissRequest = { showCustomUrlDialog = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = DarkSurfaceElevated,
                border = androidx.compose.foundation.BorderStroke(1.dp, CloudCyan.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Link, null, tint = CloudCyan, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Download Custom APK",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = "Paste any direct APK download URL to download and install via CloudCore 10 Gbps network pipeline:",
                        color = Color.LightGray,
                        fontSize = 12.sp
                    )

                    OutlinedTextField(
                        value = customApkUrlInput,
                        onValueChange = { customApkUrlInput = it },
                        placeholder = { Text("https://example.com/myapp.apk", color = Color.Gray, fontSize = 12.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CloudCyan,
                            unfocusedBorderColor = DarkCardBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    OutlinedTextField(
                        value = customApkNameInput,
                        onValueChange = { customApkNameInput = it },
                        placeholder = { Text("App Name (optional)", color = Color.Gray, fontSize = 12.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CloudCyan,
                            unfocusedBorderColor = DarkCardBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showCustomUrlDialog = false },
                            modifier = Modifier.weight(1f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
                        ) {
                            Text("Cancel", color = Color.Gray)
                        }

                        Button(
                            onClick = {
                                if (customApkUrlInput.isNotBlank()) {
                                    val title = customApkNameInput.ifBlank {
                                        customApkUrlInput.substringAfterLast("/").replace(".apk", "").capitalize().ifBlank { "Custom App" }
                                    }
                                    val pkg = "com.custom." + title.lowercase().replace(" ", "")
                                    showCustomUrlDialog = false
                                    startInstallFlow(
                                        SideloadCandidate(
                                            title = title,
                                            packageName = pkg,
                                            developer = "Custom Sideload",
                                            category = "Tools",
                                            sizeMb = 25,
                                            isGame = false,
                                            accentHex = 0xFF00E5FF,
                                            versionName = "1.0",
                                            downloadUrl = customApkUrlInput,
                                            description = "Installed from custom link: $customApkUrlInput"
                                        )
                                    )
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CloudCyan),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Download", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // 10 Gbps Download & Android Cloud Package Installer Dialog
    if (installDialogState != InstallDialogState.IDLE && activeCandidate != null) {
        val app = activeCandidate!!
        Dialog(onDismissRequest = {
            if (installDialogState == InstallDialogState.INSTALLED_SUCCESS || installDialogState == InstallDialogState.PACKAGE_INSTALLER_PROMPT) {
                installDialogState = InstallDialogState.IDLE
            }
        }) {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = DarkSurfaceElevated,
                border = androidx.compose.foundation.BorderStroke(1.dp, CloudCyan.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    when (installDialogState) {
                        InstallDialogState.DOWNLOADING_10G -> {
                            // Stage 1: 10 Gbps Ultra-Speed Download
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Speed, null, tint = CloudEmerald, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("10 Gbps Fiber Pipeline", color = CloudEmerald, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Text("9,840 Mbps", color = CloudCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color(app.accentHex)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = app.title.take(2).uppercase(),
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "Downloading ${app.title}.apk",
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${String.format("%.1f", app.sizeMb * downloadProgress)} MB / ${app.sizeMb} MB",
                                    color = Color.Gray,
                                    fontSize = 12.sp
                                )
                            }

                            LinearProgressIndicator(
                                progress = { downloadProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = CloudEmerald,
                                trackColor = DarkSurface
                            )
                        }

                        InstallDialogState.PLAY_PROTECT_SCAN -> {
                            // Stage 2: Play Protect Scan
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = CloudEmerald,
                                modifier = Modifier.size(52.dp)
                            )
                            Text(
                                text = "Google Play Protect",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Scanning package signature and bytecode for vulnerabilities...",
                                color = Color.Gray,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                            LinearProgressIndicator(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp),
                                color = CloudCyan,
                                trackColor = DarkSurface
                            )
                        }

                        InstallDialogState.PACKAGE_INSTALLER_PROMPT -> {
                            // Stage 3: Official Android Package Installer Prompt
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Android,
                                    contentDescription = null,
                                    tint = PlayGreen,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Cloud Package Installer",
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(app.accentHex)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = app.title.take(2).uppercase(),
                                        color = Color.White,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(app.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    Text(app.packageName, color = Color.Gray, fontSize = 11.sp)
                                    Text("v${app.versionName} • ${app.sizeMb} MB • ARM64-v8a", color = CloudCyan, fontSize = 10.sp)
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = DarkSurface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.CheckCircle, null, tint = CloudEmerald, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Play Protect verified: Safe to install", color = CloudEmerald, fontSize = 11.sp)
                                }
                            }

                            Text(
                                text = "Do you want to install this application into the Cloud Phone environment?",
                                color = Color.LightGray,
                                fontSize = 12.sp
                            )

                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = executeInstallToCloud,
                                    colors = ButtonDefaults.buttonColors(containerColor = CloudCyan),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.InstallMobile, null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Install to Cloud Phone", color = Color.Black, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = installToPhysicalHostDevice,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, CloudEmerald),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Android, null, tint = CloudEmerald, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Install to Host Device (APK)", color = CloudEmerald, fontSize = 12.sp)
                                }

                                OutlinedButton(
                                    onClick = { installDialogState = InstallDialogState.IDLE },
                                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Cancel", color = Color.Gray)
                                }
                            }
                        }

                        InstallDialogState.INSTALLING_SYSTEM -> {
                            // Stage 4: Installing
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(CircleShape)
                                    .background(CloudCyan.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.InstallMobile, null, tint = CloudCyan, modifier = Modifier.size(28.dp))
                            }
                            Text(
                                text = "Installing ${app.title}...",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Extracting native libraries and optimizing bytecode with ART AOT compiler...",
                                color = Color.Gray,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center
                            )
                            LinearProgressIndicator(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = CloudCyan,
                                trackColor = DarkSurface
                            )
                        }

                        InstallDialogState.INSTALLED_SUCCESS -> {
                            // Stage 5: Finished
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = CloudEmerald,
                                modifier = Modifier.size(54.dp)
                            )
                            Text(
                                text = "App installed successfully!",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${app.title} is now available on your Cloud Phone Desktop and App Drawer.",
                                color = Color.LightGray,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { installDialogState = InstallDialogState.IDLE },
                                    modifier = Modifier.weight(1f),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
                                ) {
                                    Text("Done", color = Color.White)
                                }

                                Button(
                                    onClick = {
                                        installDialogState = InstallDialogState.IDLE
                                        val installedApp = PlayApp(
                                            id = app.packageName,
                                            title = app.title,
                                            developer = app.developer,
                                            category = app.category,
                                            rating = 4.8f,
                                            reviews = "500K+",
                                            downloads = "50M+",
                                            sizeMb = app.sizeMb,
                                            isInstalled = true,
                                            description = app.description,
                                            accentHex = app.accentHex,
                                            isGame = app.isGame
                                        )
                                        onLaunchApp(installedApp)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = CloudEmerald),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.PlayArrow, null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Open", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        InstallDialogState.IDLE -> {}
                    }
                }
            }
        }
    }
}
