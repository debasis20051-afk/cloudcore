package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CloudDevice
import com.example.ui.theme.CloudCyan
import com.example.ui.theme.CloudEmerald
import com.example.ui.theme.CloudViolet
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated

@Composable
fun DeviceSpecsScreen(
    device: CloudDevice,
    onToggleRoot: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        // Top Bar
        Surface(
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Text(
                    text = "High-End Cloud Phone Specs",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Hero Flagship Benchmark Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CloudCyan.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    listOf(CloudCyan.copy(alpha = 0.15f), DarkSurfaceElevated)
                                )
                            )
                            .padding(18.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = device.brandModel,
                                        color = Color.White,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Top Tier Cloud Gaming Cluster",
                                        color = CloudCyan,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(CloudEmerald.copy(alpha = 0.2f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "120Hz ULTRA",
                                        color = CloudEmerald,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // AnTuTu Score Badge
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(DarkSurface)
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("AnTuTu Benchmark Score", color = Color.Gray, fontSize = 11.sp)
                                    Text("2,248,930", color = CloudCyan, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(CloudViolet.copy(alpha = 0.25f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("RANK #1 EXTREME", color = CloudViolet, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Specs Category: Processor & GPU
            item {
                SpecsCategoryCard(
                    title = "PROCESSOR & GRAPHICS",
                    icon = Icons.Default.Memory,
                    items = listOf(
                        "SoC Chipset" to device.soc,
                        "GPU Accelerator" to device.gpu,
                        "Hardware Ray Tracing" to "Enabled (DirectX 12 / Vulkan 1.3)",
                        "CPU Architecture" to "1x Cortex-X4 @ 3.4GHz + 5x A720 + 2x A520"
                    )
                )
            }

            // Specs Category: Memory & Storage
            item {
                SpecsCategoryCard(
                    title = "MEMORY & STORAGE",
                    icon = Icons.Default.Storage,
                    items = listOf(
                        "RAM Memory" to "${device.ramGb} GB LPDDR5X (8533 Mbps Quad-Channel)",
                        "ROM Storage" to "${device.storageGb} GB UFS 4.0 (Read 4200 MB/s, Write 2800 MB/s)",
                        "Cloud Virtual RAM" to "+16 GB Ultra Swap Enabled",
                        "File System" to "F2FS Enhanced Cloud Persistent"
                    )
                )
            }

            // Specs Category: High-Speed Internet
            item {
                SpecsCategoryCard(
                    title = "ULTRA HIGH-SPEED NETWORK",
                    icon = Icons.Default.Wifi,
                    items = listOf(
                        "Network Pipeline" to device.networkSpeed,
                        "Maximum Bandwidth" to "10,000 Mbps Full Duplex",
                        "Average Ping" to "${device.pingMs} ms (Ultra-Low Latency)",
                        "Server Node" to device.serverRegion,
                        "Wi-Fi Protocol" to "Wi-Fi 7 (802.11be) Cloud Bridged",
                        "Dedicated IP" to device.ipAddress
                    )
                )
            }

            // Specs Category: Display & System
            item {
                SpecsCategoryCard(
                    title = "DISPLAY & ANDROID OS",
                    icon = Icons.Default.Tv,
                    items = listOf(
                        "Resolution" to device.displaySpecs,
                        "Refresh Rate" to "${device.refreshRateHz} Hz High Frame Rate",
                        "Android Version" to device.osVersion,
                        "Google Play Services" to "Certified (Google Play Protect Active)",
                        "Chrome Browser" to "Installed (V8 Engine Hardware Accelerated)",
                        "Thermal / Cooling" to "${device.temperatureC}°C Liquid Vapor Chamber"
                    )
                )
            }

            // Root & Security Management
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(CloudViolet.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Security, contentDescription = null, tint = CloudViolet)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Cloud Magisk Root Access",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (device.isRooted) "Root Permission Granted (SU active)" else "Standard Unrooted Mode",
                                    color = if (device.isRooted) CloudEmerald else Color.Gray,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Switch(
                            checked = device.isRooted,
                            onCheckedChange = { onToggleRoot() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CloudEmerald,
                                checkedTrackColor = CloudEmerald.copy(alpha = 0.3f),
                                uncheckedThumbColor = Color.Gray,
                                uncheckedTrackColor = DarkSurface
                            )
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
private fun SpecsCategoryCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    items: List<Pair<String, String>>
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = null, tint = CloudCyan, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    color = CloudCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            items.forEachIndexed { index, (label, value) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Text(text = label, color = Color.Gray, fontSize = 11.sp, modifier = Modifier.width(130.dp))
                    Text(text = value, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                }
                if (index < items.size - 1) {
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(DarkSurface.copy(alpha = 0.6f)))
                }
            }
        }
    }
}
