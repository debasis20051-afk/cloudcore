package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CloudDevice
import com.example.ui.theme.CloudCyan
import com.example.ui.theme.CloudEmerald
import com.example.ui.theme.CloudViolet
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * High-end virtual Android 15 Status Bar showing 10Gbps WiFi, 120Hz indicator, and 100% Cloud Power
 */
@Composable
fun VirtualStatusBar(
    device: CloudDevice,
    pingMs: Int,
    fps: Int,
    modifier: Modifier = Modifier
) {
    var currentTime by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        while (true) {
            currentTime = sdf.format(Date())
            delay(1000)
        }
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(28.dp)
            .background(Color.Black.copy(alpha = 0.65f))
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Left: Time & 120Hz Badge
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = currentTime,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(CloudCyan.copy(alpha = 0.25f))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
                Text(
                    text = "${fps}Hz",
                    color = CloudCyan,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            if (device.isRooted) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(CloudViolet.copy(alpha = 0.25f))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = "ROOT",
                        color = CloudViolet,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Center: Dedicated 10Gbps Cloud Indicator
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(CloudEmerald)
            )
            Text(
                text = "10 Gbps Cloud",
                color = CloudEmerald,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "${pingMs}ms",
                color = Color.LightGray,
                fontSize = 10.sp
            )
        }

        // Right: 5G, Wi-Fi 7, Continuous AC Battery
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Wifi,
                contentDescription = "Wi-Fi 7 10G",
                tint = Color.White,
                modifier = Modifier.size(14.dp)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Bolt,
                    contentDescription = "Cloud Power",
                    tint = CloudEmerald,
                    modifier = Modifier.size(13.dp)
                )
                Text(
                    text = "100%",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

/**
 * Redfinger-style Floating Action Sidebar for controlling cloud phone,
 * switching resolution, toggling keymapping, AFK macro, and returning home.
 */
@Composable
fun FloatingCloudControlBar(
    isVisible: Boolean,
    isAfkActive: Boolean,
    isKeymappingActive: Boolean,
    pingMs: Int,
    fps: Int,
    onHomeClick: () -> Unit,
    onBackClick: () -> Unit,
    onToggleKeymapping: () -> Unit,
    onToggleAfk: () -> Unit,
    onSpeedtestClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onExitToConsole: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = isVisible,
        enter = slideInHorizontally { it },
        exit = slideOutHorizontally { it },
        modifier = modifier
    ) {
        Surface(
            shape = RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp),
            color = DarkSurface.copy(alpha = 0.92f),
            shadowElevation = 8.dp,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
        ) {
            Column(
                modifier = Modifier
                    .padding(vertical = 10.dp, horizontal = 6.dp)
                    .width(48.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Ping & FPS Pill
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(DarkSurfaceElevated)
                        .padding(vertical = 4.dp, horizontal = 2.dp)
                ) {
                    Text(
                        text = "${pingMs}ms",
                        color = if (pingMs < 10) CloudEmerald else Color.Yellow,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${fps}fps",
                        color = CloudCyan,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Home Action
                FloatingBarIconButton(
                    icon = Icons.Default.Home,
                    label = "Home",
                    tint = CloudCyan,
                    onClick = onHomeClick,
                    testTag = "cloud_bar_home"
                )

                // Back Action
                FloatingBarIconButton(
                    icon = Icons.Default.ArrowBack,
                    label = "Back",
                    tint = Color.White,
                    onClick = onBackClick,
                    testTag = "cloud_bar_back"
                )

                // Keymapping Gamepad Toggle
                FloatingBarIconButton(
                    icon = Icons.Default.Gamepad,
                    label = "Gamepad",
                    tint = if (isKeymappingActive) CloudCyan else Color.LightGray,
                    isHighlight = isKeymappingActive,
                    onClick = onToggleKeymapping,
                    testTag = "cloud_bar_keymap"
                )

                // AFK Auto-Macro Tool
                FloatingBarIconButton(
                    icon = if (isAfkActive) Icons.Default.Stop else Icons.Default.PlayArrow,
                    label = "AFK",
                    tint = if (isAfkActive) CloudEmerald else Color.LightGray,
                    isHighlight = isAfkActive,
                    onClick = onToggleAfk,
                    testTag = "cloud_bar_afk"
                )

                // Speedtest 10G
                FloatingBarIconButton(
                    icon = Icons.Default.Speed,
                    label = "10G Net",
                    tint = CloudCyan,
                    onClick = onSpeedtestClick,
                    testTag = "cloud_bar_speed"
                )

                // Cloud Settings
                FloatingBarIconButton(
                    icon = Icons.Default.Tune,
                    label = "Config",
                    tint = Color.White,
                    onClick = onSettingsClick,
                    testTag = "cloud_bar_config"
                )

                // Dashboard / Exit
                FloatingBarIconButton(
                    icon = Icons.Default.Dashboard,
                    label = "Fleet",
                    tint = CloudViolet,
                    onClick = onExitToConsole,
                    testTag = "cloud_bar_exit"
                )
            }
        }
    }
}

@Composable
private fun FloatingBarIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit,
    isHighlight: Boolean = false,
    testTag: String = ""
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .testTag(testTag)
            .clip(RoundedCornerShape(8.dp))
            .background(if (isHighlight) tint.copy(alpha = 0.2f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(20.dp)
        )
        Text(
            text = label,
            color = if (isHighlight) tint else Color.LightGray,
            fontSize = 7.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
