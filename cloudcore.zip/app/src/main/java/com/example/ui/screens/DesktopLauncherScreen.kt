package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shop
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.CloudDevice
import com.example.model.CloudWindow
import com.example.model.GoogleUserProfile
import com.example.model.PlayApp
import com.example.ui.components.GoogleSignInButton
import com.example.ui.components.RealAppIcon
import com.example.util.AppMetadataResolver
import com.example.ui.theme.ChromeBlue
import com.example.ui.theme.ChromeGreen
import com.example.ui.theme.ChromeRed
import com.example.ui.theme.ChromeYellow
import com.example.ui.theme.CloudCyan
import com.example.ui.theme.CloudEmerald
import com.example.ui.theme.CloudViolet
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.PlayGreen
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DesktopAppEntry(
    val id: String,
    val title: String,
    val targetWindow: CloudWindow? = null,
    val playApp: PlayApp? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DesktopLauncherScreen(
    device: CloudDevice,
    installedApps: List<PlayApp>,
    googleUser: GoogleUserProfile? = null,
    runWhenPhoneOff: Boolean = true,
    onLaunchWindow: (CloudWindow) -> Unit,
    onLaunchApp: (PlayApp) -> Unit,
    showDrawer: Boolean,
    onToggleDrawer: (Boolean) -> Unit,
    onGoogleAccountClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var currentTime by remember { mutableStateOf("") }
    var currentDate by remember { mutableStateOf("") }
    var drawerFilter by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        val dateFmt = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault())
        while (true) {
            val now = Date()
            currentTime = timeFmt.format(now)
            currentDate = dateFmt.format(now)
            delay(1000)
        }
    }

    // Clean, authentic desktop apps with real icons and zero duplicates
    val desktopApps = remember(installedApps) {
        val list = mutableListOf<DesktopAppEntry>()

        // 1. Google Play Store
        list.add(DesktopAppEntry("com.android.vending", "Play Store", targetWindow = CloudWindow.GOOGLE_PLAY_STORE))

        // 2. Google Chrome
        list.add(DesktopAppEntry("com.android.chrome", "Chrome", targetWindow = CloudWindow.CHROME_BROWSER))

        // 3. YouTube
        val ytApp = installedApps.find { it.id == "com.google.android.youtube" }
        list.add(DesktopAppEntry("com.google.android.youtube", "YouTube", playApp = ytApp))

        // 4. Google Drive
        val driveApp = installedApps.find { it.id == "com.google.android.apps.docs" }
        list.add(DesktopAppEntry("com.google.android.apps.docs", "Google Drive", playApp = driveApp))

        // 5. Discord
        val discordApp = installedApps.find { it.id == "com.discord" }
        list.add(DesktopAppEntry("com.discord", "Discord", playApp = discordApp))

        // 6. Spotify
        val spotifyApp = installedApps.find { it.id == "com.spotify.music" }
        list.add(DesktopAppEntry("com.spotify.music", "Spotify", playApp = spotifyApp))

        // 7. Device Specs
        list.add(DesktopAppEntry("specs", "Device Specs", targetWindow = CloudWindow.DEVICE_SPECS))

        // 8. System Settings
        list.add(DesktopAppEntry("settings", "Settings", targetWindow = CloudWindow.CLOUD_SETTINGS))

        // Excluded apps requested to be removed
        val excludedKeywords = listOf("telegram", "vlc", "termux", "speedtest", "antutu", "android apps")

        // Any extra user-installed apps (e.g. Roblox, Minecraft, TikTok, etc.)
        installedApps.forEach { extra ->
            val resolved = AppMetadataResolver.resolve(extra.id, extra.title)
            val isExcluded = excludedKeywords.any {
                extra.id.contains(it, ignoreCase = true) || extra.title.contains(it, ignoreCase = true) || resolved.title.contains(it, ignoreCase = true)
            }
            val isKnown = list.any { it.id == extra.id } || extra.id.contains("chrome")
            if (!isExcluded && !isKnown) {
                list.add(DesktopAppEntry(extra.id, resolved.title, playApp = extra.copy(title = resolved.title)))
            }
        }

        list
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        // High-End Custom Curved Waves Wallpaper Background
        Image(
            painter = painterResource(id = R.drawable.img_custom_wallpaper_1790348100481),
            contentDescription = "Cloud Wallpaper",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Dark gradient scrim
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color.Black.copy(alpha = 0.25f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.55f)
                        )
                    )
                )
        )

        // Desktop Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top System & Clock Widget
            Column {
                Spacer(modifier = Modifier.height(6.dp))

                // Desktop Top Status: Google Account & 24/7 Run-When-Off
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (googleUser != null) {
                        GoogleSignInButton(
                            user = googleUser,
                            onClick = onGoogleAccountClick,
                            compact = true,
                            testTag = "desktop_google_account_btn"
                        )
                    } else {
                        Spacer(modifier = Modifier.width(1.dp))
                    }

                    if (runWhenPhoneOff) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = CloudEmerald.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CloudEmerald.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(CloudEmerald)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "24/7 Run When Off",
                                    color = CloudEmerald,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = currentTime,
                    color = Color.White,
                    fontSize = 52.sp,
                    fontWeight = FontWeight.Light,
                    letterSpacing = (-1).sp
                )
                Text(
                    text = currentDate,
                    color = Color.LightGray,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Snapdragon 8 Gen 3 & 10G Fiber Telemetry Widget
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color.Black.copy(alpha = 0.6f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CloudCyan.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(CloudEmerald)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Snapdragon 8 Gen 3 Extreme",
                                color = CloudCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "10 Gbps • ${device.pingMs}ms",
                            color = CloudEmerald,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Google Search Bar (Launches Chrome with search)
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = DarkSurfaceElevated.copy(alpha = 0.9f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onLaunchWindow(CloudWindow.CHROME_BROWSER) }
                        .testTag("desktop_google_search_bar")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Google 'G' Icon
                        Text(
                            text = "G",
                            color = ChromeBlue,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Search Google with 10 Gbps speed...",
                            color = Color.Gray,
                            fontSize = 13.sp,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = Color.LightGray,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Desktop App Grid
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                verticalArrangement = Arrangement.spacedBy(20.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                items(desktopApps) { app ->
                    DesktopIconItem(
                        appId = app.id,
                        label = app.title,
                        onClick = {
                            if (app.targetWindow != null) {
                                onLaunchWindow(app.targetWindow)
                            } else if (app.playApp != null) {
                                onLaunchApp(app.playApp)
                            } else {
                                val match = installedApps.find { it.id == app.id }
                                if (match != null) {
                                    onLaunchApp(match)
                                } else if (app.id.contains("chrome")) {
                                    onLaunchWindow(CloudWindow.CHROME_BROWSER)
                                } else if (app.id.contains("speedtest")) {
                                    onLaunchWindow(CloudWindow.SPEEDTEST)
                                }
                            }
                        },
                        testTag = "desktop_app_${app.id}"
                    )
                }
            }

            // Bottom System Dock
            Surface(
                shape = RoundedCornerShape(26.dp),
                color = DarkSurface.copy(alpha = 0.85f),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Dialer shortcut
                    DockIconItem(
                        appId = "phone",
                        contentDesc = "Phone",
                        onClick = { /* simulated dialer */ },
                        testTag = "dock_phone_btn"
                    )

                    // Chrome Browser (Official Logo)
                    DockIconItem(
                        appId = "com.android.chrome",
                        contentDesc = "Google Chrome",
                        onClick = { onLaunchWindow(CloudWindow.CHROME_BROWSER) },
                        testTag = "dock_chrome_btn"
                    )

                    // App Drawer Launcher
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(CloudCyan.copy(alpha = 0.2f))
                            .clickable { onToggleDrawer(true) }
                            .testTag("dock_app_drawer_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Apps,
                            contentDescription = "App Drawer",
                            tint = CloudCyan,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    // Google Play Store (Official Logo)
                    DockIconItem(
                        appId = "com.android.vending",
                        contentDesc = "Google Play Store",
                        onClick = { onLaunchWindow(CloudWindow.GOOGLE_PLAY_STORE) },
                        testTag = "dock_playstore_btn"
                    )

                    // Settings
                    DockIconItem(
                        appId = "settings",
                        contentDesc = "Settings",
                        onClick = { onLaunchWindow(CloudWindow.CLOUD_SETTINGS) },
                        testTag = "dock_settings_btn"
                    )
                }
            }
        }

        // Full App Drawer Modal
        if (showDrawer) {
            ModalBottomSheet(
                onDismissRequest = { onToggleDrawer(false) },
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                containerColor = DarkSurface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = "Installed Apps & Tools",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Running in cloud with 10 Gbps connection",
                        color = CloudCyan,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = drawerFilter,
                        onValueChange = { drawerFilter = it },
                        placeholder = { Text("Search installed apps...", color = Color.Gray, fontSize = 13.sp) },
                        singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CloudCyan,
                            unfocusedBorderColor = DarkCardBorder,
                            focusedContainerColor = DarkSurfaceElevated,
                            unfocusedContainerColor = DarkSurfaceElevated
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    val excludedDrawerKeywords = listOf("telegram", "vlc", "termux", "speedtest", "antutu", "android apps")
                    val allDrawerApps = installedApps
                        .filterNot { app ->
                            excludedDrawerKeywords.any {
                                app.title.contains(it, ignoreCase = true) || app.id.contains(it, ignoreCase = true)
                            }
                        }
                        .filter {
                            drawerFilter.isEmpty() || it.title.contains(drawerFilter, ignoreCase = true)
                        }

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        verticalArrangement = Arrangement.spacedBy(18.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(360.dp)
                    ) {
                        items(allDrawerApps) { app ->
                            val resolvedTitle = AppMetadataResolver.resolve(app.id, app.title).title
                            DesktopIconItem(
                                appId = app.id,
                                label = resolvedTitle,
                                onClick = {
                                    onToggleDrawer(false)
                                    if (app.id == "com.android.chrome") {
                                        onLaunchWindow(CloudWindow.CHROME_BROWSER)
                                    } else {
                                        onLaunchApp(app.copy(title = resolvedTitle))
                                    }
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    }
}

@Composable
private fun DesktopIconItem(
    appId: String,
    label: String,
    onClick: () -> Unit,
    testTag: String = ""
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        RealAppIcon(
            appId = appId,
            title = label,
            size = 54.dp
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = label,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun DockIconItem(
    appId: String,
    contentDesc: String,
    onClick: () -> Unit,
    testTag: String = ""
) {
    Box(
        modifier = Modifier
            .size(46.dp)
            .clickable(onClick = onClick)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        RealAppIcon(
            appId = appId,
            title = contentDesc,
            size = 46.dp
        )
    }
}
