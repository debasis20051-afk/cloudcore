package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CloudDao {
    // Installed Apps
    @Query("SELECT * FROM installed_apps ORDER BY installedAt DESC")
    fun getAllInstalledApps(): Flow<List<InstalledAppEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInstalledApp(app: InstalledAppEntity)

    @Query("DELETE FROM installed_apps WHERE appId = :appId")
    suspend fun deleteInstalledApp(appId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM installed_apps WHERE appId = :appId)")
    suspend fun isAppInstalled(appId: String): Boolean

    // Speedtest
    @Query("SELECT * FROM speedtest_records ORDER BY timestamp DESC LIMIT 20")
    fun getSpeedtestHistory(): Flow<List<SpeedtestRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSpeedtest(record: SpeedtestRecordEntity)

    // Bookmarks
    @Query("SELECT * FROM chrome_bookmarks ORDER BY timestamp DESC")
    fun getChromeBookmarks(): Flow<List<ChromeBookmarkEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: ChromeBookmarkEntity)

    @Query("DELETE FROM chrome_bookmarks WHERE id = :id")
    suspend fun deleteBookmark(id: Long)

    // Device Config
    @Query("SELECT * FROM device_configs WHERE deviceId = :deviceId LIMIT 1")
    fun getDeviceConfig(deviceId: String): Flow<DeviceConfigEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveDeviceConfig(config: DeviceConfigEntity)
}
