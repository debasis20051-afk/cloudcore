package com.example.data.repository

import com.example.data.local.CloudDao
import com.example.data.local.DeviceConfigEntity
import com.example.data.local.InstalledAppEntity
import com.example.data.local.SpeedtestRecordEntity
import com.example.data.local.ChromeBookmarkEntity
import kotlinx.coroutines.flow.Flow

class CloudRepository(private val dao: CloudDao) {
    val installedApps: Flow<List<InstalledAppEntity>> = dao.getAllInstalledApps()
    val speedtestHistory: Flow<List<SpeedtestRecordEntity>> = dao.getSpeedtestHistory()
    val bookmarks: Flow<List<ChromeBookmarkEntity>> = dao.getChromeBookmarks()

    fun getDeviceConfig(deviceId: String): Flow<DeviceConfigEntity?> =
        dao.getDeviceConfig(deviceId)

    suspend fun installApp(app: InstalledAppEntity) {
        dao.insertInstalledApp(app)
    }

    suspend fun uninstallApp(appId: String) {
        dao.deleteInstalledApp(appId)
    }

    suspend fun recordSpeedtest(record: SpeedtestRecordEntity) {
        dao.insertSpeedtest(record)
    }

    suspend fun addBookmark(title: String, url: String) {
        dao.insertBookmark(ChromeBookmarkEntity(title = title, url = url))
    }

    suspend fun deleteBookmark(id: Long) {
        dao.deleteBookmark(id)
    }

    suspend fun saveDeviceConfig(config: DeviceConfigEntity) {
        dao.saveDeviceConfig(config)
    }
}
