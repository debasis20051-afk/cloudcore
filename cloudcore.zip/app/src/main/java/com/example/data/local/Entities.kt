package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "installed_apps")
data class InstalledAppEntity(
    @PrimaryKey val appId: String,
    val title: String,
    val developer: String,
    val category: String,
    val iconHex: Long,
    val installedAt: Long = System.currentTimeMillis(),
    val sizeMb: Int,
    val isGame: Boolean
)

@Entity(tableName = "speedtest_records")
data class SpeedtestRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val downloadMbps: Float,
    val uploadMbps: Float,
    val pingMs: Int,
    val jitterMs: Float,
    val serverName: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "chrome_bookmarks")
data class ChromeBookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val url: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "device_configs")
data class DeviceConfigEntity(
    @PrimaryKey val deviceId: String,
    val name: String,
    val isRooted: Boolean,
    val refreshRateHz: Int,
    val resolutionMode: String,
    val virtualGps: String,
    val serverRegion: String,
    val afkMacroActive: Boolean
)
