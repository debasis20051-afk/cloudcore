package com.example

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.CloudWindow
import com.example.service.CloudKeepAliveService
import com.example.ui.components.GoogleAccountAuthDialog
import com.example.ui.components.SimulatedScreenOffOverlay
import com.example.ui.screens.CloudPhoneScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.checkIfAppInstalled
import com.example.ui.theme.ChromeBlue
import com.example.ui.theme.CloudCyan
import com.example.ui.theme.CloudEmerald
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.PlayGreen
import com.example.viewmodel.CloudPhoneViewModel

enum class AppViewMode {
    HOMEPAGE,
    DASHBOARD_CONSOLE,
    CLOUD_DEVICE_STREAM
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                CloudCoreApp()
            }
        }
    }
}

@Composable
fun CloudCoreApp(
    viewModel: CloudPhoneViewModel = viewModel()
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val playApps by viewModel.playApps.collectAsStateWithLifecycle()
    val speedtestHistory by viewModel.speedtestHistory.collectAsStateWithLifecycle()

    var viewMode by remember { mutableStateOf(AppViewMode.HOMEPAGE) }

    // Start 24/7 background keep-alive service when user enables runWhenPhoneOff
    LaunchedEffect(uiState.runWhenPhoneOff) {
        if (uiState.runWhenPhoneOff) {
            try {
                CloudKeepAliveService.start(context)
            } catch (_: Exception) {
                // Ignore service start exception in test environments
            }
        } else {
            try {
                CloudKeepAliveService.stop(context)
            } catch (_: Exception) {
                // Ignore
            }
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg),
        bottomBar = {
            // Show bottom navigation bar on Homepage and Fleet Dashboard
            if (viewMode != AppViewMode.CLOUD_DEVICE_STREAM) {
                NavigationBar(
                    containerColor = DarkSurface,
                    contentColor = Color.White,
                    tonalElevation = 6.dp,
                    modifier = Modifier.navigationBarsPadding()
                ) {
                    NavigationBarItem(
                        selected = viewMode == AppViewMode.HOMEPAGE,
                        onClick = { viewMode = AppViewMode.HOMEPAGE },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Homepage") },
                        label = { Text("Home", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            indicatorColor = CloudCyan,
                            selectedTextColor = CloudCyan,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_home")
                    )

                    NavigationBarItem(
                        selected = viewMode == AppViewMode.DASHBOARD_CONSOLE,
                        onClick = { viewMode = AppViewMode.DASHBOARD_CONSOLE },
                        icon = { Icon(Icons.Default.Cloud, contentDescription = "Fleet Console") },
                        label = { Text("Cloud Fleet", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            indicatorColor = CloudCyan,
                            selectedTextColor = CloudCyan,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_console")
                    )

                    NavigationBarItem(
                        selected = false,
                        onClick = {
                            viewModel.navigateTo(CloudWindow.HOME_LAUNCHER)
                            viewMode = AppViewMode.CLOUD_DEVICE_STREAM
                        },
                        icon = { Icon(Icons.Default.PhoneAndroid, contentDescription = "Cloud Phone") },
                        label = { Text("Desktop", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            unselectedIconColor = CloudCyan,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_stream")
                    )

                    NavigationBarItem(
                        selected = false,
                        onClick = {
                            viewModel.navigateTo(CloudWindow.CHROME_BROWSER)
                            viewMode = AppViewMode.CLOUD_DEVICE_STREAM
                        },
                        icon = { Icon(Icons.Default.Language, contentDescription = "Chrome", tint = ChromeBlue) },
                        label = { Text("Chrome", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            unselectedIconColor = ChromeBlue,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_chrome")
                    )

                    NavigationBarItem(
                        selected = false,
                        onClick = {
                            viewModel.navigateTo(CloudWindow.GOOGLE_PLAY_STORE)
                            viewMode = AppViewMode.CLOUD_DEVICE_STREAM
                        },
                        icon = { Icon(Icons.Default.PlayArrow, contentDescription = "Google Play", tint = PlayGreen) },
                        label = { Text("Play Store", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            unselectedIconColor = PlayGreen,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_playstore")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = viewMode,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "viewModeTransition"
            ) { mode ->
                when (mode) {
                    AppViewMode.HOMEPAGE -> {
                        HomeScreen(
                            activeDevice = uiState.activeDevice,
                            googleUser = uiState.googleUser,
                            runWhenPhoneOff = uiState.runWhenPhoneOff,
                            offlineHours = uiState.offlineRunHours,
                            offlineExp = uiState.offlineFarmedExp,
                            offlineGold = uiState.offlineFarmedGold,
                            onEnterCloudDevice = {
                                viewModel.navigateTo(CloudWindow.HOME_LAUNCHER)
                                viewMode = AppViewMode.CLOUD_DEVICE_STREAM
                            },
                            onOpenChrome = {
                                viewModel.navigateTo(CloudWindow.CHROME_BROWSER)
                                viewMode = AppViewMode.CLOUD_DEVICE_STREAM
                            },
                            onOpenPlayStore = {
                                viewModel.navigateTo(CloudWindow.GOOGLE_PLAY_STORE)
                                viewMode = AppViewMode.CLOUD_DEVICE_STREAM
                            },
                            onOpenSpeedtest = {
                                viewModel.navigateTo(CloudWindow.SPEEDTEST)
                                viewMode = AppViewMode.CLOUD_DEVICE_STREAM
                            },
                            onOpenSpecs = {
                                viewModel.navigateTo(CloudWindow.DEVICE_SPECS)
                                viewMode = AppViewMode.CLOUD_DEVICE_STREAM
                            },
                            onToggleRunWhenPhoneOff = { viewModel.toggleRunWhenPhoneOff() },
                            onSimulatePhoneOff = { viewModel.toggleSimulateScreenOff(true) },
                            onGoogleLoginClick = { viewModel.showGoogleLoginDialog(true) },
                            onRebootCloudDevice = { viewModel.rebootCloudPhone() },
                            isRebooting = uiState.isRebooting,
                            modifier = Modifier.statusBarsPadding()
                        )
                    }

                    AppViewMode.DASHBOARD_CONSOLE -> {
                        DashboardScreen(
                            devices = uiState.deviceList,
                            activeDevice = uiState.activeDevice,
                            googleUser = uiState.googleUser,
                            runWhenPhoneOff = uiState.runWhenPhoneOff,
                            onSelectDevice = { dev ->
                                viewModel.switchDevice(dev)
                                viewMode = AppViewMode.CLOUD_DEVICE_STREAM
                            },
                            onEnterCloudDevice = {
                                viewModel.navigateTo(CloudWindow.HOME_LAUNCHER)
                                viewMode = AppViewMode.CLOUD_DEVICE_STREAM
                            },
                            onOpenChrome = {
                                viewModel.navigateTo(CloudWindow.CHROME_BROWSER)
                                viewMode = AppViewMode.CLOUD_DEVICE_STREAM
                            },
                            onOpenPlayStore = {
                                viewModel.navigateTo(CloudWindow.GOOGLE_PLAY_STORE)
                                viewMode = AppViewMode.CLOUD_DEVICE_STREAM
                            },
                            onOpenSpeedtest = {
                                viewModel.navigateTo(CloudWindow.SPEEDTEST)
                                viewMode = AppViewMode.CLOUD_DEVICE_STREAM
                            },
                            onRebootDevice = { viewModel.rebootCloudPhone() },
                            onGoogleLoginClick = { viewModel.showGoogleLoginDialog(true) },
                            isRebooting = uiState.isRebooting,
                            modifier = Modifier.statusBarsPadding()
                        )
                    }

                    AppViewMode.CLOUD_DEVICE_STREAM -> {
                        CloudPhoneScreen(
                            uiState = uiState,
                            playApps = playApps,
                            speedtestHistory = speedtestHistory,
                            onNavigateWindow = { window -> viewModel.navigateTo(window) },
                            onGoHome = { viewModel.goHome() },
                            onToggleDrawer = { open -> viewModel.toggleAppDrawer(open) },
                            onToggleKeymapping = { viewModel.toggleKeymappingOverlay() },
                            onToggleAfk = { viewModel.toggleAfkMacro() },
                            onInstallApp = { appId -> viewModel.installAppFromPlayStore(appId) },
                            onUninstallApp = { appId -> viewModel.uninstallApp(appId) },
                            onSelectPlayCategory = { cat -> viewModel.setPlayCategory(cat) },
                            onPlaySearchChange = { q -> viewModel.setPlaySearchQuery(q) },
                            onChromeNavigate = { url -> viewModel.navigateChromeUrl(url) },
                            onChromeNewTab = { viewModel.openNewChromeTab() },
                            onInstallCustomApk = { title, pkg, dev, cat, size, isGame, hex ->
                                viewModel.installCustomApk(title, pkg, dev, cat, size, isGame, hex)
                            },
                            onLaunchApp = { app ->
                                val isNative = checkIfAppInstalled(context, app.id)
                                val launchIntent = if (isNative) context.packageManager.getLaunchIntentForPackage(app.id) else null
                                if (launchIntent != null) {
                                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    context.startActivity(launchIntent)
                                    Toast.makeText(context, "Launching native ${app.title}...", Toast.LENGTH_SHORT).show()
                                } else {
                                    viewModel.launchApp(app)
                                }
                            },
                            onStartSpeedtest = { viewModel.runSpeedtest() },
                            onToggleRoot = { viewModel.toggleRoot() },
                            onSetQuality = { q -> viewModel.setStreamQuality(q) },
                            onSetLocation = { loc -> viewModel.setVirtualLocation(loc) },
                            onReboot = { viewModel.rebootCloudPhone() },
                            onExitToDashboard = { viewMode = AppViewMode.HOMEPAGE },
                            onGoogleLoginClick = { viewModel.showGoogleLoginDialog(true) },
                            onToggleRunWhenPhoneOff = { viewModel.toggleRunWhenPhoneOff() },
                            modifier = Modifier.statusBarsPadding()
                        )
                    }
                }
            }

            // Google Account Sign-In / Account Details Modal Dialog
            if (uiState.isGoogleLoginDialogVisible) {
                GoogleAccountAuthDialog(
                    user = uiState.googleUser,
                    isLoading = uiState.isSigningInGoogle,
                    onSignIn = { email, name -> viewModel.signInWithGoogle(email, name) },
                    onSignOut = { viewModel.signOutGoogle() },
                    onDismiss = { viewModel.showGoogleLoginDialog(false) }
                )
            }

            // Physical Phone Screen Off Simulation Overlay
            SimulatedScreenOffOverlay(
                isVisible = uiState.isScreenOffSimulated,
                onWakeUp = { viewModel.toggleSimulateScreenOff(false) },
                activeDevice = uiState.activeDevice,
                afkExp = uiState.afkEarnedExp,
                afkGold = uiState.afkEarnedGold,
                clickCount = uiState.afkClickCount
            )
        }
    }
}
