package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.DefaultData
import com.example.data.local.AppDatabase
import com.example.data.local.DeviceConfigEntity
import com.example.data.local.InstalledAppEntity
import com.example.data.local.SpeedtestRecordEntity
import com.example.data.repository.CloudRepository
import com.example.model.CloudDevice
import com.example.model.CloudWindow
import com.example.model.DeviceStatus
import com.example.model.GoogleUserProfile
import com.example.model.PlayApp
import com.example.model.SpeedtestResult
import com.example.model.StreamQuality
import com.example.util.AppMetadataResolver
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

data class CloudPhoneUiState(
    val currentWindow: CloudWindow = CloudWindow.HOME_LAUNCHER,
    val isConnectedToCloud: Boolean = true,
    val activeDevice: CloudDevice = DefaultData.flagshipDevice,
    val deviceList: List<CloudDevice> = listOf(DefaultData.flagshipDevice, DefaultData.secondaryDevice),
    val showFloatingBar: Boolean = true,
    val showKeymappingOverlay: Boolean = false,
    val isAfkMacroActive: Boolean = false,
    val afkClickCount: Int = 0,
    val afkEarnedExp: Long = 18450,
    val afkEarnedGold: Long = 124900,
    val streamPingMs: Int = 3,
    val streamFps: Int = 120,
    val streamBitrateMbps: Float = 48.5f,
    val showAppDrawer: Boolean = false,
    val selectedPlayApp: PlayApp? = null,
    val playStoreCategory: String = "For You",
    val searchQuery: String = "",
    // Run-When-Phone-Is-Off 24/7 Cloud Background Engine
    val runWhenPhoneOff: Boolean = true,
    val isScreenOffSimulated: Boolean = false,
    val offlineRunHours: Int = 168, // 7 days uninterrupted continuous cloud runtime
    val offlineFarmedExp: Long = 34520,
    val offlineFarmedGold: Long = 289400,
    // Google Account integration state
    val googleUser: GoogleUserProfile = GoogleUserProfile(
        isSignedIn = false,
        displayName = "Debasis Gamer",
        email = "debasis20051@gmail.com",
        avatarInitial = "D"
    ),
    val isGoogleLoginDialogVisible: Boolean = false,
    val isSigningInGoogle: Boolean = false,
    // Chrome Browser state
    val chromeUrl: String = "https://www.google.com",
    val chromeInputUrl: String = "https://www.google.com",
    val chromeTabsCount: Int = 1,
    val chromeCanGoBack: Boolean = false,
    val chromeCanGoForward: Boolean = false,
    val isChromeLoading: Boolean = false,
    val chromeLoadingProgress: Int = 100,
    // Speedtest state
    val isTestingSpeed: Boolean = false,
    val speedtestPhase: String = "IDLE", // IDLE, PING, DOWNLOAD, UPLOAD, FINISHED
    val currentDownloadSpeedMbps: Float = 0f,
    val currentUploadSpeedMbps: Float = 0f,
    val latestTestResult: SpeedtestResult? = null,
    val isRebooting: Boolean = false,
    val currentRunningApp: PlayApp? = null
)

class CloudPhoneViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: CloudRepository

    private val _uiState = MutableStateFlow(CloudPhoneUiState())
    val uiState: StateFlow<CloudPhoneUiState> = _uiState.asStateFlow()

    private val _playApps = MutableStateFlow(DefaultData.initialPlayApps)
    val playApps: StateFlow<List<PlayApp>> = _playApps.asStateFlow()

    private var telemetryJob: Job? = null
    private var afkMacroJob: Job? = null
    private var speedtestJob: Job? = null
    private var installJobs = mutableMapOf<String, Job>()

    init {
        val db = AppDatabase.getDatabase(application)
        repository = CloudRepository(db.cloudDao())

        // Seed initial apps into Room if empty & remove any removed/bogus entities
        viewModelScope.launch {
            try {
                repository.uninstallApp("com.google.android.apps")
                repository.uninstallApp("com.google.android.apps.play")
                repository.uninstallApp("org.telegram.messenger")
                repository.uninstallApp("org.videolan.vlc")
                repository.uninstallApp("com.termux")
                repository.uninstallApp("com.ookla.speedtest10g")
                repository.uninstallApp("com.antutu.ABenchMark")
            } catch (_: Exception) {}

            _playApps.value.filter { it.isInstalled }.forEach { app ->
                repository.installApp(
                    InstalledAppEntity(
                        appId = app.id,
                        title = app.title,
                        developer = app.developer,
                        category = app.category,
                        iconHex = app.accentHex,
                        sizeMb = app.sizeMb,
                        isGame = app.isGame
                    )
                )
            }

            // Continuously observe Room and resolve authentic app names/icons
            repository.installedApps.collect { entities ->
                entities.forEach { entity ->
                    val resolved = AppMetadataResolver.resolve(entity.appId, entity.title)
                    if (entity.title != resolved.title || entity.category != resolved.category) {
                        repository.installApp(
                            entity.copy(
                                title = resolved.title,
                                category = resolved.category,
                                isGame = resolved.isGame
                            )
                        )
                    }
                }

                _playApps.update { currentList ->
                    val updated = currentList.map { app ->
                        val match = entities.find { it.appId == app.id }
                        if (match != null) {
                            val resolved = AppMetadataResolver.resolve(app.id, match.title)
                            app.copy(
                                title = resolved.title,
                                developer = resolved.developer,
                                category = resolved.category,
                                isInstalled = true,
                                isGame = resolved.isGame
                            )
                        } else {
                            app
                        }
                    }.toMutableList()

                    entities.forEach { entity ->
                        if (updated.none { it.id == entity.appId }) {
                            val resolved = AppMetadataResolver.resolve(entity.appId, entity.title)
                            updated.add(
                                PlayApp(
                                    id = entity.appId,
                                    title = resolved.title,
                                    developer = resolved.developer,
                                    category = resolved.category,
                                    rating = 4.8f,
                                    reviews = "500K+",
                                    downloads = "50M+",
                                    sizeMb = entity.sizeMb,
                                    isInstalled = true,
                                    description = "Running on 10 Gbps Cloud Phone. Play Protect verified safe.",
                                    accentHex = resolved.accentHex,
                                    isGame = resolved.isGame
                                )
                            )
                        }
                    }
                    updated
                }
            }
        }

        startTelemetryMonitor()
    }

    val installedAppsFromDb = repository.installedApps
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val speedtestHistory = repository.speedtestHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private fun startTelemetryMonitor() {
        telemetryJob?.cancel()
        telemetryJob = viewModelScope.launch {
            while (true) {
                delay(2000)
                _uiState.update { current ->
                    val jitter = (Random.nextFloat() * 2f - 1f)
                    val basePing = current.activeDevice.pingMs
                    val newPing = (basePing + jitter.toInt()).coerceIn(2, 8)
                    val newBitrate = (48f + Random.nextFloat() * 4f)
                    current.copy(
                        streamPingMs = newPing,
                        streamBitrateMbps = String.format("%.1f", newBitrate).toFloat()
                    )
                }
            }
        }
    }

    fun switchDevice(device: CloudDevice) {
        _uiState.update {
            it.copy(
                activeDevice = device,
                currentWindow = CloudWindow.HOME_LAUNCHER,
                streamFps = device.refreshRateHz,
                streamPingMs = device.pingMs
            )
        }
    }

    fun navigateTo(window: CloudWindow) {
        _uiState.update { it.copy(currentWindow = window, showAppDrawer = false) }
    }

    fun goHome() {
        _uiState.update { it.copy(currentWindow = CloudWindow.HOME_LAUNCHER, showAppDrawer = false) }
    }

    fun toggleAppDrawer(open: Boolean? = null) {
        _uiState.update { it.copy(showAppDrawer = open ?: !it.showAppDrawer) }
    }

    fun toggleFloatingBar() {
        _uiState.update { it.copy(showFloatingBar = !it.showFloatingBar) }
    }

    fun toggleKeymappingOverlay() {
        _uiState.update { it.copy(showKeymappingOverlay = !it.showKeymappingOverlay) }
    }

    fun toggleAfkMacro() {
        val willRun = !_uiState.value.isAfkMacroActive
        _uiState.update { it.copy(isAfkMacroActive = willRun) }

        if (willRun) {
            afkMacroJob?.cancel()
            afkMacroJob = viewModelScope.launch {
                while (_uiState.value.isAfkMacroActive) {
                    delay(800)
                    _uiState.update {
                        it.copy(
                            afkClickCount = it.afkClickCount + 1,
                            afkEarnedExp = it.afkEarnedExp + Random.nextLong(20, 80),
                            afkEarnedGold = it.afkEarnedGold + Random.nextLong(150, 450)
                        )
                    }
                }
            }
        } else {
            afkMacroJob?.cancel()
        }
    }

    fun selectPlayApp(app: PlayApp?) {
        _uiState.update { it.copy(selectedPlayApp = app) }
    }

    fun setPlayCategory(category: String) {
        _uiState.update { it.copy(playStoreCategory = category) }
    }

    fun setPlaySearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun installAppFromPlayStore(appId: String) {
        val app = _playApps.value.find { it.id == appId } ?: return
        if (app.isInstalled || app.isInstalling) return

        // Set installing status
        _playApps.update { list ->
            list.map { if (it.id == appId) it.copy(isInstalling = true, installProgress = 0.05f) else it }
        }

        // Simulate lightning-fast 10Gbps download & install
        val job = viewModelScope.launch {
            val totalSteps = 10
            for (step in 1..totalSteps) {
                delay(200) // 2 seconds total for massive app!
                val progress = step.toFloat() / totalSteps
                _playApps.update { list ->
                    list.map { if (it.id == appId) it.copy(installProgress = progress) else it }
                }
            }

            // Mark as installed
            _playApps.update { list ->
                list.map {
                    if (it.id == appId) it.copy(
                        isInstalled = true,
                        isInstalling = false,
                        installProgress = 1f
                    ) else it
                }
            }

            // Save to Room
            repository.installApp(
                InstalledAppEntity(
                    appId = app.id,
                    title = app.title,
                    developer = app.developer,
                    category = app.category,
                    iconHex = app.accentHex,
                    sizeMb = app.sizeMb,
                    isGame = app.isGame
                )
            )

            if (_uiState.value.selectedPlayApp?.id == appId) {
                _uiState.update { it.copy(selectedPlayApp = it.selectedPlayApp?.copy(isInstalled = true, isInstalling = false)) }
            }
        }
        installJobs[appId] = job
    }

    fun uninstallApp(appId: String) {
        viewModelScope.launch {
            repository.uninstallApp(appId)
            _playApps.update { list ->
                list.map { if (it.id == appId) it.copy(isInstalled = false, isInstalling = false, installProgress = 0f) else it }
            }
            if (_uiState.value.selectedPlayApp?.id == appId) {
                _uiState.update { it.copy(selectedPlayApp = it.selectedPlayApp?.copy(isInstalled = false)) }
            }
        }
    }

    fun installCustomApk(
        title: String,
        packageName: String,
        developer: String,
        category: String,
        sizeMb: Int,
        isGame: Boolean,
        accentHex: Long = 0xFF0284C7
    ) {
        val resolved = AppMetadataResolver.resolve(packageName, title)
        val finalTitle = resolved.title
        val finalDev = if (developer.contains("Google Play", ignoreCase = true) || developer.isEmpty()) resolved.developer else developer
        val finalCat = if (category == "Play Store App" || category.isEmpty()) resolved.category else category
        val finalIsGame = isGame || resolved.isGame
        val finalAccent = if (accentHex == 0xFF0284C7L || accentHex == 0xFF0F9D58L) resolved.accentHex else accentHex

        val excludedKeywords = listOf("telegram", "vlc", "termux", "speedtest", "antutu", "android apps")
        if (excludedKeywords.any { finalTitle.contains(it, ignoreCase = true) || packageName.contains(it, ignoreCase = true) } ||
            packageName == "com.google.android.apps" || packageName == "com.google.android.apps.play") {
            return
        }

        val existing = _playApps.value.find { it.id == packageName }
        if (existing != null) {
            installAppFromPlayStore(packageName)
            return
        }

        val newApp = PlayApp(
            id = packageName,
            title = finalTitle,
            developer = finalDev,
            category = finalCat,
            rating = 4.8f,
            reviews = "500K+",
            downloads = "50M+",
            sizeMb = sizeMb,
            isInstalled = false,
            isInstalling = true,
            installProgress = 0.2f,
            description = "Installed via 10 Gbps Cloud pipeline. Play Protect verified safe.",
            badge = "10G Sideload",
            accentHex = finalAccent,
            isGame = finalIsGame
        )

        _playApps.update { listOf(newApp) + it }

        viewModelScope.launch {
            for (step in 2..10) {
                delay(120)
                _playApps.update { list ->
                    list.map { if (it.id == packageName) it.copy(installProgress = step / 10f) else it }
                }
            }

            _playApps.update { list ->
                list.map {
                    if (it.id == packageName) it.copy(
                        isInstalled = true,
                        isInstalling = false,
                        installProgress = 1f
                    ) else it
                }
            }

            repository.installApp(
                InstalledAppEntity(
                    appId = packageName,
                    title = finalTitle,
                    developer = finalDev,
                    category = finalCat,
                    iconHex = finalAccent,
                    sizeMb = sizeMb,
                    isGame = finalIsGame
                )
            )
        }
    }

    fun launchApp(app: PlayApp) {
        if (app.id == "com.ookla.speedtest10g") {
            navigateTo(CloudWindow.SPEEDTEST)
        } else if (app.id == "com.antutu.ABenchMark") {
            navigateTo(CloudWindow.DEVICE_SPECS)
        } else if (app.id == "com.android.chrome") {
            navigateTo(CloudWindow.CHROME_BROWSER)
        } else {
            _uiState.update {
                it.copy(
                    currentRunningApp = app,
                    currentWindow = CloudWindow.RUNNING_APP,
                    showAppDrawer = false
                )
            }
        }
    }

    // Chrome Browser Actions
    fun navigateChromeUrl(url: String) {
        val formatted = if (url.startsWith("http://") || url.startsWith("https://")) {
            url
        } else if (url.contains(".") && !url.contains(" ")) {
            "https://$url"
        } else {
            "https://www.google.com/search?q=" + java.net.URLEncoder.encode(url, "UTF-8")
        }
        _uiState.update {
            it.copy(
                chromeUrl = formatted,
                chromeInputUrl = formatted,
                isChromeLoading = true,
                chromeLoadingProgress = 20
            )
        }
    }

    fun updateChromeInput(input: String) {
        _uiState.update { it.copy(chromeInputUrl = input) }
    }

    fun setChromeLoading(loading: Boolean, progress: Int = 100) {
        _uiState.update {
            it.copy(
                isChromeLoading = loading,
                chromeLoadingProgress = progress
            )
        }
    }

    fun addChromeBookmark(title: String, url: String) {
        viewModelScope.launch {
            repository.addBookmark(title, url)
        }
    }

    fun openNewChromeTab() {
        _uiState.update {
            it.copy(
                chromeTabsCount = it.chromeTabsCount + 1,
                chromeUrl = "https://www.google.com",
                chromeInputUrl = "https://www.google.com"
            )
        }
    }

    // 10 Gbps Speedtest Engine
    fun runSpeedtest() {
        if (_uiState.value.isTestingSpeed) return
        speedtestJob?.cancel()

        speedtestJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isTestingSpeed = true,
                    speedtestPhase = "PING",
                    currentDownloadSpeedMbps = 0f,
                    currentUploadSpeedMbps = 0f
                )
            }
            delay(1000)

            // Download Test: Ramps up to ~9,840 Mbps (10 Gbps Fiber)
            _uiState.update { it.copy(speedtestPhase = "DOWNLOAD") }
            val downloadTargets = listOf(1420f, 3850f, 6900f, 8940f, 9650f, 9842f, 9815f)
            for (speed in downloadTargets) {
                _uiState.update { it.copy(currentDownloadSpeedMbps = speed) }
                delay(400)
            }

            // Upload Test: Ramps up to ~9,250 Mbps
            _uiState.update { it.copy(speedtestPhase = "UPLOAD") }
            val uploadTargets = listOf(1200f, 3400f, 6100f, 8400f, 9150f, 9280f)
            for (speed in uploadTargets) {
                _uiState.update { it.copy(currentUploadSpeedMbps = speed) }
                delay(400)
            }

            val finalDownload = 9842.5f
            val finalUpload = 9280.0f
            val result = SpeedtestResult(
                downloadMbps = finalDownload,
                uploadMbps = finalUpload,
                pingMs = _uiState.value.activeDevice.pingMs,
                jitterMs = _uiState.value.activeDevice.jitterMs,
                server = _uiState.value.activeDevice.serverRegion
            )

            _uiState.update {
                it.copy(
                    isTestingSpeed = false,
                    speedtestPhase = "FINISHED",
                    currentDownloadSpeedMbps = finalDownload,
                    currentUploadSpeedMbps = finalUpload,
                    latestTestResult = result
                )
            }

            repository.recordSpeedtest(
                SpeedtestRecordEntity(
                    downloadMbps = finalDownload,
                    uploadMbps = finalUpload,
                    pingMs = result.pingMs,
                    jitterMs = result.jitterMs,
                    serverName = result.server
                )
            )
        }
    }

    // Cloud Device Controls
    fun toggleRoot() {
        val currentRoot = _uiState.value.activeDevice.isRooted
        val updated = _uiState.value.activeDevice.copy(isRooted = !currentRoot)
        _uiState.update { it.copy(activeDevice = updated) }
    }

    fun setStreamQuality(quality: StreamQuality) {
        val updated = _uiState.value.activeDevice.copy(
            quality = quality,
            refreshRateHz = quality.fps
        )
        _uiState.update {
            it.copy(
                activeDevice = updated,
                streamFps = quality.fps
            )
        }
    }

    fun setVirtualLocation(locationName: String) {
        val updated = _uiState.value.activeDevice.copy(virtualGps = locationName)
        _uiState.update { it.copy(activeDevice = updated) }
    }

    fun rebootCloudPhone() {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isRebooting = true,
                    activeDevice = it.activeDevice.copy(status = DeviceStatus.REBOOTING)
                )
            }
            delay(2500)
            _uiState.update {
                it.copy(
                    isRebooting = false,
                    activeDevice = it.activeDevice.copy(status = DeviceStatus.ONLINE_RUNNING),
                    currentWindow = CloudWindow.HOME_LAUNCHER
                )
            }
        }
    }

    // Run-When-Phone-Is-Off Cloud Engine Actions
    fun toggleRunWhenPhoneOff() {
        val current = _uiState.value.runWhenPhoneOff
        _uiState.update {
            it.copy(
                runWhenPhoneOff = !current,
                googleUser = it.googleUser.copy(backgroundKeepAlive = !current)
            )
        }
    }

    fun toggleSimulateScreenOff(isOff: Boolean) {
        _uiState.update { it.copy(isScreenOffSimulated = isOff) }
    }

    // Google Account Sign-In Flow
    fun showGoogleLoginDialog(show: Boolean) {
        _uiState.update { it.copy(isGoogleLoginDialogVisible = show) }
    }

    fun signInWithGoogle(email: String = "debasis20051@gmail.com", displayName: String = "Debasis") {
        viewModelScope.launch {
            _uiState.update { it.copy(isSigningInGoogle = true) }
            delay(1200) // Realistic secure Google authentication delay
            _uiState.update {
                it.copy(
                    isSigningInGoogle = false,
                    isGoogleLoginDialogVisible = false,
                    googleUser = GoogleUserProfile(
                        isSignedIn = true,
                        displayName = displayName,
                        email = email,
                        avatarInitial = displayName.firstOrNull()?.uppercase() ?: "G",
                        subscriptionTier = "VIP Ultra Lifetime",
                        cloudStorageUsedGb = 32.4f,
                        cloudStorageTotalGb = 512.0f,
                        syncStatus = "Active & Synced with Google Account",
                        backgroundKeepAlive = true
                    )
                )
            }
        }
    }

    fun signOutGoogle() {
        _uiState.update {
            it.copy(
                googleUser = GoogleUserProfile(
                    isSignedIn = false,
                    displayName = "Guest Gamer",
                    email = "guest@cloudphone.vip",
                    avatarInitial = "G"
                ),
                isGoogleLoginDialogVisible = false
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        telemetryJob?.cancel()
        afkMacroJob?.cancel()
        speedtestJob?.cancel()
        installJobs.values.forEach { it.cancel() }
    }
}
