package com.example.util

data class ResolvedAppMetadata(
    val title: String,
    val developer: String,
    val category: String,
    val isGame: Boolean,
    val accentHex: Long
)

object AppMetadataResolver {

    /**
     * Resolves real, authentic titles and metadata for popular apps and games,
     * replacing generic fallbacks like "Client" or raw package suffixes.
     */
    fun resolve(packageName: String, candidateTitle: String? = null): ResolvedAppMetadata {
        val pkg = packageName.lowercase().trim()
        val cand = candidateTitle?.trim()?.takeIf {
            it.isNotEmpty() &&
            !it.equals("client", ignoreCase = true) &&
            !it.equals("app", ignoreCase = true) &&
            !it.equals("mobile", ignoreCase = true) &&
            !it.contains("android apps", ignoreCase = true) &&
            !it.contains("google play", ignoreCase = true)
        }

        // 1. Exact or keyword package dictionary
        return when {
            // ROBLOX
            pkg == "com.roblox.client" || pkg.contains("roblox") -> ResolvedAppMetadata(
                title = "Roblox",
                developer = "Roblox Corporation",
                category = "Adventure & Virtual Universes",
                isGame = true,
                accentHex = 0xFF111827
            )

            // MINECRAFT
            pkg.contains("minecraft") -> ResolvedAppMetadata(
                title = "Minecraft",
                developer = "Mojang",
                category = "Arcade & Sandbox",
                isGame = true,
                accentHex = 0xFF22C55E
            )

            // FREE FIRE
            pkg.contains("freefire") || pkg.contains("dts.freefire") -> ResolvedAppMetadata(
                title = "Free Fire MAX",
                developer = "Garena International",
                category = "Action & Battle Royale",
                isGame = true,
                accentHex = 0xFFF97316
            )

            // PUBG MOBILE
            pkg.contains("pubg") || pkg.contains("tencent.ig") -> ResolvedAppMetadata(
                title = "PUBG Mobile",
                developer = "Level Infinite",
                category = "Action & Battle Royale",
                isGame = true,
                accentHex = 0xFFEAB308
            )

            // CALL OF DUTY
            pkg.contains("callofduty") || pkg.contains("activision") -> ResolvedAppMetadata(
                title = "Call of Duty: Mobile",
                developer = "Activision Publishing",
                category = "Action & Shooter",
                isGame = true,
                accentHex = 0xFF0284C7
            )

            // GENSHIN IMPACT
            pkg.contains("genshin") || pkg.contains("mihoyo") -> ResolvedAppMetadata(
                title = "Genshin Impact",
                developer = "COGNOSPHERE PTE. LTD.",
                category = "Open World RPG",
                isGame = true,
                accentHex = 0xFF8B5CF6
            )

            // BRAWL STARS
            pkg.contains("brawlstars") -> ResolvedAppMetadata(
                title = "Brawl Stars",
                developer = "Supercell",
                category = "Action & Multiplayer",
                isGame = true,
                accentHex = 0xFFF59E0B
            )

            // CLASH OF CLANS
            pkg.contains("clashofclans") -> ResolvedAppMetadata(
                title = "Clash of Clans",
                developer = "Supercell",
                category = "Strategy",
                isGame = true,
                accentHex = 0xFFEAB308
            )

            // SUBWAY SURFERS
            pkg.contains("subwaysurf") -> ResolvedAppMetadata(
                title = "Subway Surfers",
                developer = "SYBO Games",
                category = "Arcade & Runner",
                isGame = true,
                accentHex = 0xFFEF4444
            )

            // AMONG US
            pkg.contains("amongus") || pkg.contains("spacemafia") -> ResolvedAppMetadata(
                title = "Among Us",
                developer = "Innersloth LLC",
                category = "Action & Social Deduction",
                isGame = true,
                accentHex = 0xFFEF4444
            )

            // TIKTOK
            pkg.contains("tiktok") || pkg.contains("musically") || pkg.contains("trill") -> ResolvedAppMetadata(
                title = "TikTok",
                developer = "TikTok Pte. Ltd.",
                category = "Video & Entertainment",
                isGame = false,
                accentHex = 0xFF000000
            )

            // INSTAGRAM
            pkg.contains("instagram") -> ResolvedAppMetadata(
                title = "Instagram",
                developer = "Instagram",
                category = "Social & Photo",
                isGame = false,
                accentHex = 0xFFE1306C
            )

            // WHATSAPP
            pkg.contains("whatsapp") -> ResolvedAppMetadata(
                title = "WhatsApp Messenger",
                developer = "WhatsApp LLC",
                category = "Communication",
                isGame = false,
                accentHex = 0xFF25D366
            )

            // FACEBOOK
            pkg.contains("facebook") || pkg.contains("katana") -> ResolvedAppMetadata(
                title = "Facebook",
                developer = "Meta Platforms, Inc.",
                category = "Social",
                isGame = false,
                accentHex = 0xFF1877F2
            )

            // NETFLIX
            pkg.contains("netflix") -> ResolvedAppMetadata(
                title = "Netflix",
                developer = "Netflix, Inc.",
                category = "Entertainment & Movies",
                isGame = false,
                accentHex = 0xFFE50914
            )

            // X / TWITTER
            pkg.contains("twitter") || pkg.contains("x.android") -> ResolvedAppMetadata(
                title = "X (Twitter)",
                developer = "X Corp.",
                category = "News & Social",
                isGame = false,
                accentHex = 0xFF000000
            )

            // SPOTIFY
            pkg.contains("spotify") -> ResolvedAppMetadata(
                title = "Spotify",
                developer = "Spotify AB",
                category = "Music & Audio",
                isGame = false,
                accentHex = 0xFF1DB954
            )

            // DISCORD
            pkg.contains("discord") -> ResolvedAppMetadata(
                title = "Discord",
                developer = "Discord Inc.",
                category = "Communication & Gaming",
                isGame = false,
                accentHex = 0xFF5865F2
            )

            // GITHUB
            pkg.contains("github") -> ResolvedAppMetadata(
                title = "GitHub",
                developer = "GitHub, Inc.",
                category = "Productivity & Developer",
                isGame = false,
                accentHex = 0xFF24292E
            )

            // YOUTUBE
            pkg.contains("youtube") -> ResolvedAppMetadata(
                title = "YouTube",
                developer = "Google LLC",
                category = "Video Players & Editors",
                isGame = false,
                accentHex = 0xFFFF0000
            )

            // GOOGLE DRIVE
            pkg.contains("docs") || pkg.contains("drive") -> ResolvedAppMetadata(
                title = "Google Drive",
                developer = "Google LLC",
                category = "Productivity & Cloud",
                isGame = false,
                accentHex = 0xFF0F9D58
            )

            // CHROME
            pkg.contains("chrome") -> ResolvedAppMetadata(
                title = "Google Chrome",
                developer = "Google LLC",
                category = "Communication & Browser",
                isGame = false,
                accentHex = 0xFF4285F4
            )

            // 2. Intelligent heuristics for other packages
            else -> {
                val cleanTitle = if (cand != null) {
                    cand
                } else {
                    deriveTitleFromPackage(pkg)
                }

                val isGameLikely = pkg.contains("game") || pkg.contains("games") ||
                        pkg.contains("play") || pkg.contains("studio") ||
                        cleanTitle.contains("RPG", ignoreCase = true) ||
                        cleanTitle.contains("War", ignoreCase = true)

                val accent = generateColorHash(pkg)

                ResolvedAppMetadata(
                    title = cleanTitle,
                    developer = "Google Play Verified",
                    category = if (isGameLikely) "Games & Entertainment" else "Cloud Applications",
                    isGame = isGameLikely,
                    accentHex = accent
                )
            }
        }
    }

    /**
     * Extracts a clean, human-friendly brand name from reverse-DNS package names.
     * E.g. "com.roblox.client" -> "Roblox" (avoids "Client")
     * E.g. "com.supercell.brawlstars" -> "Brawl Stars"
     */
    fun deriveTitleFromPackage(pkg: String): String {
        val segments = pkg.split(".").filter { it.isNotBlank() }
        if (segments.isEmpty()) return "Application"

        // Ignore common meaningless tail segments
        val genericTails = setOf("client", "android", "app", "mobile", "lite", "free", "main", "core", "release")
        var chosen = segments.last()

        if (chosen.lowercase() in genericTails && segments.size > 2) {
            // Take the penultimate segment (e.g. "roblox" from "com.roblox.client")
            chosen = segments[segments.size - 2]
        }

        // Format snake_case, camelCase, or plain name
        val formatted = chosen
            .replace("_", " ")
            .replace("-", " ")
            .split(" ")
            .joinToString(" ") { word ->
                word.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
            }

        return formatted.ifEmpty { "Cloud App" }
    }

    private fun generateColorHash(key: String): Long {
        val hash = key.hashCode().toLong()
        val palette = listOf(
            0xFF2563EB, 0xFF7C3AED, 0xFF059669, 0xFFDC2626,
            0xFFD97706, 0xFF0891B2, 0xFF4F46E5, 0xFFBE185D
        )
        val index = kotlin.math.abs(hash % palette.size).toInt()
        return palette[index]
    }
}
