package com.example.model

enum class DeviceStatus(val label: String) {
    ONLINE_RUNNING("24/7 Online Active"),
    AFK_FARMING("AFK Auto-Farming"),
    REBOOTING("Rebooting Node..."),
    STANDBY("Cloud Standby")
}

enum class StreamQuality(val label: String, val resolution: String, val fps: Int, val bitrateMbps: Int) {
    BALANCED_720P("Balanced 720p", "1280x720", 60, 15),
    HIGH_1080P("Ultra HD 1080p", "1920x1080", 60, 30),
    EXTREME_2K_120FPS("Extreme 2K 120Hz HDR", "3200x1440", 120, 65)
}

enum class CloudWindow(val title: String) {
    HOME_LAUNCHER("Desktop"),
    GOOGLE_PLAY_STORE("App Store"),
    CHROME_BROWSER("Chrome"),
    SPEEDTEST("Speedtest 10G"),
    DEVICE_SPECS("Device Specs"),
    RUNNING_APP("Running App"),
    CLOUD_SETTINGS("Cloud Settings")
}

data class CloudDevice(
    val id: String,
    val name: String,
    val brandModel: String,
    val soc: String,
    val gpu: String,
    val ramGb: Int,
    val storageGb: Int,
    val osVersion: String,
    val displaySpecs: String,
    val refreshRateHz: Int,
    val networkSpeed: String,
    val serverRegion: String,
    val ipAddress: String,
    val pingMs: Int,
    val jitterMs: Float,
    val status: DeviceStatus,
    val batteryPercent: Int = 100, // Unlimited cloud AC direct feed
    val temperatureC: Int = 29,
    val isRooted: Boolean = true,
    val virtualGps: String = "Tokyo, Shinjuku (35.6938° N, 139.7034° E)",
    val uptimeHours: Int = 432,
    val quality: StreamQuality = StreamQuality.EXTREME_2K_120FPS
)

data class PlayApp(
    val id: String,
    val title: String,
    val developer: String,
    val category: String,
    val rating: Float,
    val reviews: String,
    val downloads: String,
    val sizeMb: Int,
    val isInstalled: Boolean,
    val isInstalling: Boolean = false,
    val installProgress: Float = 0f,
    val description: String,
    val badge: String? = null,
    val bannerUrl: String? = null,
    val accentHex: Long = 0xFF00E5FF,
    val isGame: Boolean = false
)

data class ChromeTab(
    val id: String,
    val title: String,
    val url: String
)

data class SpeedtestResult(
    val downloadMbps: Float,
    val uploadMbps: Float,
    val pingMs: Int,
    val jitterMs: Float,
    val server: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class GoogleUserProfile(
    val isSignedIn: Boolean = false,
    val displayName: String = "Guest Gamer",
    val email: String = "guest@cloudphone.vip",
    val avatarInitial: String = "G",
    val subscriptionTier: String = "VIP Ultra",
    val cloudStorageUsedGb: Float = 14.8f,
    val cloudStorageTotalGb: Float = 256.0f,
    val syncStatus: String = "Synced to Google Cloud",
    val backgroundKeepAlive: Boolean = true
)
